/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package create_a_java_console_program_to_normalize_text;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author MSI GL63
 */
public class Normalize {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            File f = new File("D:\\FUDA 3\\LAB 211 - OOP with Java Lab\\CODE\\LAB211\\LAB211\\src\\main\\java\\create_a_java_console_program_to_normalize_text\\input.txt");
            FileReader fr = new FileReader(f);
            PrintWriter pw;
            try (BufferedReader br = new BufferedReader(fr)) {
                File f2 = new File("D:\\FUDA 3\\LAB 211 - OOP with Java Lab\\CODE\\LAB211\\LAB211\\src\\main\\java\\create_a_java_console_program_to_normalize_text\\output.txt");
                FileWriter fw = new FileWriter(f2, true);
                BufferedWriter bw = new BufferedWriter(fw);
                pw = new PrintWriter(fw);
                String line;
                while((line = br.readLine()) != null){
                    if(Validation.isLineEmpty(line))
                        continue;
                    line = Validation.normalizeOneSpaceWordAndSpecialCharacter(line);
                    line = Validation.normalizeOneSpaceAfterSpecialCharacter(line);
                    line = Validation.firstCharacterAfterDotAndColon(line);
                    line = Validation.noSpaceInQuotes(line);
                    line = Validation.noSpaceInParenthese(line);
                    line = Validation.firstCharacterInFirstLine(line);
                    line = Validation.dotAtEnd(line);
                    pw.print(line);
                }
            }
            pw.close();
            System.err.println("Normalize successful! ");
        } 
        catch (FileNotFoundException e) {
            System.err.println("File can't not found!");
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
    
}
