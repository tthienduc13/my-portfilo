/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_java_console_program_to_normalize_text;

/**
 *
 * @author MSI GL63
 */
public class Validation {
    
    private static int countQuotes = 0;
    private static int countPar = 0;
    
    public static String normalizeOneSpaceSpecialCharacter(String line, String character){
        StringBuilder stringBuffer = new StringBuilder();
        String[] strings = line.split("\\s*\\" + character + "\\s*");
        // tach chuoi dua tren space => character & word -> Array
        for (String word : strings) {
            stringBuffer.append(word + " " + character);
            stringBuffer.append(" ");
            // append : noi moi tu ngan cach voi ki tu 1 space, truoc va sau ki tu la mot space
        }
        return stringBuffer.toString().trim().substring(0, stringBuffer.length() - 3);
    }
    
    public static String normalizeOneSpaceWordAndSpecialCharacter(String line){
        line = line.toLowerCase();
        // tat ca ki tu la chu thuong
        line = line.replaceAll("\\s+", " ");
        // thay the chuoi space -> one space
        line = line.replaceFirst(" ", "");
        line = normalizeOneSpaceSpecialCharacter(line, "\"");
        line = normalizeOneSpaceSpecialCharacter(line, ",");
        line = normalizeOneSpaceSpecialCharacter(line, ".");
        line = normalizeOneSpaceSpecialCharacter(line, ":");
        return line.trim(); 
        // xoa space dau cuoi
    }
    
    public static String normalizeOneSpaceAfterSpecialCharacter(String line){
        StringBuffer stringBuffer = new StringBuffer(line);
        // dua chuoi (line) vao buffer
        for (int i = 1; i < stringBuffer.length(); i++) {
            if(stringBuffer.charAt(i) == ' ' && (stringBuffer.charAt(i + 1) == ','||stringBuffer.charAt(i + 1) == '.'||stringBuffer.charAt(i + 1) == ':'))
                stringBuffer.deleteCharAt(i);
            // Tim va xoa cac space truoc cac ki tu , . : 
        }
        return stringBuffer.toString().trim();
    }
    
    public static String firstCharacterAfterDotAndColon(String line){
        StringBuffer stringBuffer = new StringBuffer(line);
        for (int i = 0; i < stringBuffer.length() - 2; i++) {
            if(stringBuffer.charAt(i) == '.' || stringBuffer.charAt(i) == ':')
                stringBuffer.setCharAt(i + 2, Character.toUpperCase(stringBuffer.charAt(i + 2)));
            // Neu tai i la dau . thi ki tu tai vi tri i + 2 (sau . la space) la ki tu in hoa
        }
        return stringBuffer.toString().trim();
    }
    
    public static String firstCharacterInFirstLine(String line){
        line = line.substring(0);
        StringBuffer stringBuffer = new StringBuffer(line);
        for (int i = 0; i < line.length(); i++) {
            if (Character.isLetter(line.charAt(i))){
                stringBuffer.setCharAt(i, Character.toUpperCase(line.charAt(i)));
                break;
            }
            // in hoa chu cai dau cua cau dau tien
        }
        return stringBuffer.toString().trim();
    }
    
    public static String noSpaceInQuotes(String line){
        StringBuffer stringBuffer = new StringBuffer(line);
        for (int i = 1; i < stringBuffer.length(); i++) {
            if(stringBuffer.charAt(i) == '"' && countQuotes % 2 == 0){
                stringBuffer.deleteCharAt(i + 1);
                countQuotes ++;
            }
            else if(stringBuffer.charAt(i)== '"' && countQuotes % 2 == 1 && i != 0){
                stringBuffer.deleteCharAt(i - 1);
                countQuotes ++;
            }
        }
        return stringBuffer.toString().trim();
    }          
    
    public static String noSpaceInParenthese(String line){
        StringBuffer stringBuffer = new StringBuffer(line);
        for (int i = 1; i < stringBuffer.length(); i++) {
            if(stringBuffer.charAt(i) == '(' && countPar % 2 == 0){
                stringBuffer.deleteCharAt(i + 1);
                countPar ++;
            }
            else if(stringBuffer.charAt(i)== ')' && countPar % 2 == 1 && i != 0){
                stringBuffer.deleteCharAt(i - 1);
                countPar ++;
            }
        }
        return stringBuffer.toString().trim();
    }
    
    public static String dotAtEnd(String line){
        if(line.length() == 0)
            return line;
        else if(line.endsWith("."))
            return line;
        else
            return line + ".\n";       
    }
    
    public static boolean isLineEmpty(String line){
        if(line.length() == 0)
            return true;
        else
            return false;
    }
    
}
