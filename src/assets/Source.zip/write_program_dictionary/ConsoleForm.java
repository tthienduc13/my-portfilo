/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package write_program_dictionary;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    Manage manage = new Manage();
    private List<String> choices = Arrays.asList("======== Dictionary program ========",
                                                "\t1. Add Word",
                                                "\t2. Delete Word",
                                                "\t3. Translate",
                                                "\t4. Exit",
                                                "========================================",
                                                "Enter your choice: ");
    
    public int getChoice() {
        Scanner sc = new Scanner(System.in);
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 4);
    }
    
    
    public void execute(){
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    manage.addWord();
                    break;
                case 2:
                    manage.removeWord();
                    break;
                case 3:
                    manage.translate();
                    break;
                case 4: 
                    System.exit(0); 
            }
        } 
    } 
    
}
