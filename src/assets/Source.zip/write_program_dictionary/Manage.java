/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package write_program_dictionary;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author MSI GL63
 */
public class Manage {
    
    HashMap<String, String> dict = new HashMap<>();
    
    public void addWord(){
        while (true) {            
            System.out.println("------------- Add -------------");
            System.out.print("Enter English: ");
            String eng = Validation.checkInputString();
            if(!Validation.checkKeywordExist(dict, eng))
                    return;
            System.out.print("Enter Vietnamese: ");
            String vietNam = Validation.checkInputString();
            //check exist
            dict.put(eng, vietNam);
            System.err.println("Successful!");
            if(Validation.inputYN() == false){
                break;
            }
        }
        
    }
    
    public void removeWord() {
        System.out.println("------------ Delete ----------------");         
        System.out.print("Enter English: ");
        String eng = Validation.checkInputString();
        dict.remove(eng);
        System.err.println("Successful!");
    }
    
    public void translate() {
        System.out.println("------------- Translate ------------");
        System.out.print("Enter English: ");
        String eng = Validation.checkInputString();
        Set<Map.Entry<String, String>> entries = dict.entrySet();
        for (Map.Entry entry : entries) {
            if (entry.getKey().equals(eng)) {
                System.out.println("Vietnamese: " + entry.getValue());
                return;
            }
        }
        System.err.println("Word not found!");
    }
     
}
