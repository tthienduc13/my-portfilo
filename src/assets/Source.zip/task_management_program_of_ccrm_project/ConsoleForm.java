/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package task_management_program_of_ccrm_project;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    int idList = 0;
    TaskManage manageTask = new TaskManage();
    private List<String> choices = Arrays.asList("========= Task program =========",
                                                 "1. Add Task",
                                                 "2. Delete Task",
                                                 "3. Display Task",
                                                 "4. Exit",
                                                 "================================",
                                                 "Enter your choice: ");
    
    public int getChoice() {
        Scanner sc = new Scanner(System.in);
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 4);
    }
    
    public void addTask(){
        Scanner sc = new Scanner(System.in);         
            Task task = new Task();
            System.out.println("------------Add Task---------------");
            System.out.println("Requirement Name: ");
            task.setRequirementName(Validation.checkInputString());
            System.out.println("Task Type: ");
            task.setTaskTypeId(Validation.checkInputTaskTypeId());
            System.out.println("Date: ");
            task.setDate(Validation.checkInputDate());
            System.out.println("From: ");
            task.setPlanFrom(Validation.checkInputPlan());
            while (true){
                System.out.println("To: ");
                task.setPlanTo(Validation.checkInputPlan());  
                if(Float.parseFloat(task.getPlanFrom()) > Float.parseFloat(task.getPlanTo())){
                    System.err.println("Plan from must be less than plan to!");
                    System.out.println("Please enter again: ");
                }
                else
                    break;
            }
                System.out.println("Assignee: ");
                task.setAssignee(Validation.checkInputString());
                System.out.println("Reviewer: ");
                task.setReviewer(Validation.checkInputString());
                task.setId(idList);
                manageTask.addTask(task);
                System.out.println("Successful!");
    }                      
    
    public void displayTask(){
        System.out.println("----------------------------------------- Task ---------------------------------------");
        System.out.printf("%-5s%-20s%-10s%-15s%-10s%-20s%-20s\n", "ID", "Name", "Task Type", "Date", "Time", "Assignee", "Reviewer");
        ArrayList<Task> temp = manageTask.printTask();
    }  
    
    public void deleteTask(){
        Scanner sc = new Scanner(System.in);
        System.out.println("---------Del Task------");
        System.out.println("ID: ");
        int idDelete = Validation.checkInputInteger();
        manageTask.Delete(idDelete);
    }
    
    public void execute() {
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    idList ++;
                    addTask();
                    break;
                case 2:
                    deleteTask();
                    break;
                case 3:
                    displayTask();
                    break;
                case 4: 
                    System.exit(0); 
            }
        }
    }
}
