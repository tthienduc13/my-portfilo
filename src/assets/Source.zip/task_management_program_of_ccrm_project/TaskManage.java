/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package task_management_program_of_ccrm_project;

import java.util.ArrayList;

/**
 *
 * @author MSI GL63
 */
public class TaskManage {
    private ArrayList<Task> taskArrayList = new ArrayList<>();

    public TaskManage() {}
    
    public TaskManage(ArrayList<Task> taskArrayList){
        this.taskArrayList = taskArrayList;
    }

    public ArrayList<Task> getTaskArrayList() {
        return taskArrayList;
    }

    public void setTaskArrayList(ArrayList<Task> taskArrayList) {
        this.taskArrayList = taskArrayList;
    }
    
    public void addTask (Task t){
        taskArrayList.add(t);      
    }
    
    public void Delete(int idDelete){
        int count = 0;
        for (int i = 0; i < taskArrayList.size(); i++) {
            if(taskArrayList.get(i).getId() == idDelete){
                taskArrayList.remove(i);
                count ++;
            }
        }
        if(count == 0)
            System.err.println("ID isn't exist to delete!");
        else 
            System.out.println("Successful!");
    }
    
    public ArrayList<Task> printTask(){
        ArrayList<Task> result = new ArrayList<>();
        for (Task t : taskArrayList){
            System.out.printf("%-5d%-20s%-10s%-15s%-10s%-20s%-20s\n", t.getId(), t.getRequirementName(), t.getTaskTypeId(), t.getDate(), Float.parseFloat(t.getPlanTo()) - Float.parseFloat(t.getPlanFrom()), t.getAssignee(), t.getReviewer());
        }
        return result;
    }
    
}
