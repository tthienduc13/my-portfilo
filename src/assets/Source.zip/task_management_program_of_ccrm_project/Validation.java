/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package task_management_program_of_ccrm_project;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class Validation {
    
    public static Scanner sc = new Scanner(System.in);
    private static String VALID_PLAN = "[0-9]{1,2}.5|[0-9]{1,2}.0$";
    
    public static int checkInputInteger(){
        Scanner sc = new Scanner (System.in);
        while(true){            
            try{
                Integer input = null;
                String intInput = sc.nextLine();
                input = new Integer(intInput);
                if(input > 0)
                    return input;
                else
                    System.err.println("Please input a positive integer number!");
                    System.out.println("Please enter again: ");
            } 
            catch(NumberFormatException e){
                System.err.println("Please input a integer number!");
                System.out.println("Please enter again: "); 
            }
        }       
    }
    
    public static int checkInputIntLimit(int min, int max) {
        while(true){
            try{
                int input = checkInputInteger();
                if (input < min || input > max)
                    throw new NumberFormatException();
                return input;
            } 
            catch(NumberFormatException e){
                System.err.println("Please input number in rage [" + min + ", " + max + "]!");
                System.out.print("Please enter again: ");
            }
        }
    }
    
    public static String checkInputString(){
        while(true){
            String input = sc.nextLine();
            if(input.isEmpty()){
                System.err.println("Please input a string!");
                System.out.println("Please enter again: ");
            }
            else
                return input;
        }
    }
    
    public static String checkInputTaskTypeId(){
        while(true){
            int id = checkInputIntLimit(1, 4);
            String taskTypeId = null;
            switch(id){
                case 1:
                    taskTypeId = "Code";
                    break;
                case 2:
                    taskTypeId = "Test";
                    break;
                case 3:
                    taskTypeId = "Design";
                    break;
                case 4:
                    taskTypeId = "Review";
                    break;
            }
        return taskTypeId;
        }
    }

    public static String checkInputDate(){
        while(true){            
            String input = checkInputString();
            try {
                Date date = new SimpleDateFormat("dd-MM-yyyy").parse(input);
                return input;
            }   
            catch(ParseException ex) {
                System.err.println("Date to correct format(dd-mm-yyyy)");
                System.out.print("Please enter again: ");
            }
        }
    }
    
    public static String checkInputPlan(){
        while(true){
            String input = checkInputString();
            if(input.matches(VALID_PLAN) && Float.parseFloat(input) >= 8.0 && Float.parseFloat(input) <= 17.5)
               return input;
            else{
                System.err.println("Plan must from 8.0 to 17.5!");
                System.out.println("Please enter again: ");        
            }
        }
    }
    
}
