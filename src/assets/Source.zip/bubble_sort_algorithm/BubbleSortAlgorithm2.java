/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bubble_sort_algorithm;

import java.util.Scanner;
import java.util.Random;

/**
 * @author MSI GL63
 */
class Array{
    int a[];
    public Array() {
    }
    public Array(int[] a) {
        this.a = a;
    }   
    static int getSize(){
        System.out.println("Enter number of array: ");
        int size = checkValueOfSize();
        return size;
    }
    static int checkValueOfSize(){
        Scanner sc = new Scanner (System.in);
        while (true) {            
            try {
                Integer size = null;
                String intSize = sc.nextLine();
                size = new Integer(intSize);
                if(size>0){
                    return size;
                }
                else{
                    System.out.println("Please input positive number!");
                }
            } catch (NumberFormatException e) {
                System.err.println("Please input number!");
                System.out.println("Please enter again: "); 
            }
        }       
    }
    static int [] randomValue(){
        Random rd = new Random();
        int size = getSize();
        int a[] = new int[size];
        System.out.println("Unsorted array: ");
        System.out.print("[");
        for(int i = 0; i < size; i++){ 
            a[i]=rd.nextInt(20);
            System.out.print(a[i]+", ");
        }
        System.out.print("]");
        return a;
    }
    static int [] sortByBubbleSort(){
        int a[] = randomValue();
        for (int i = 0; i < a.length - 1; i++) {
            boolean swap = false;
            for(int j = 0; j < a.length - 1 - i; j++){  
                if(a[j] > a[j+1]){
                int temp = a[j];
                    a[j] = a[j+1];
                    a[j+1] = temp;
                    swap = true;    
                if(swap == false)
                    break;
                }   
            }
        }
        return a;
    }
    void outputAfterSort(){
        int a[] = sortByBubbleSort();
        System.out.println("");
        System.out.println("Sorted array: ");
        System.out.print("[");
        for(int i = 0; i < a.length; i++) 
            System.out.print(a[i]+", ");
        System.out.println("]");
    }
}
public class BubbleSortAlgorithm2 {
    public static void main(String[] args) {
        Array n = new Array();
        n.outputAfterSort();
    }
    
}
