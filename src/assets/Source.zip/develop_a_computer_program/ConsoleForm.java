/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package develop_a_computer_program;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    private List<String> choices = Arrays.asList("========= Calculator Program =========",
                                                 "1. Normal Calculator",
                                                 "2. BMI Calculator",
                                                 "3. Exit",
                                                 "============================",
                                                 "Please choice one option:");
    
    public int getChoice() {
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 3);
    }
    
    public static double enterNumber() {
        System.out.print("Enter number: ");
        double number = Validation.checkInputDouble();
        return number;
    }
    
    public void normalCalculator(){
        double temp;
        System.out.println("----- Normal Calculator -----");
        System.out.println("Enter number: ");
        temp = Validation.checkInputDouble();
        while (true) {            
            System.out.println("Enter Operator: ");
            String operator = Validation.checkInputOperator();
            if(operator.equalsIgnoreCase("+")){
                temp += enterNumber();
                System.out.println("Memory: " + temp);
            }
            if(operator.equalsIgnoreCase("-")){
                temp -= enterNumber();
                System.out.println("Memory: " + temp);
            }
            if(operator.equalsIgnoreCase("*")){
                temp *= enterNumber();
                System.out.println("Memory: " + temp);
            }
            if(operator.equalsIgnoreCase("/")){
                temp /= enterNumber();
                System.out.println("Memory: " + temp);
            }
            if(operator.equalsIgnoreCase("^")){
                temp = Math.pow(temp, enterNumber());
                System.out.println("Memory: " + temp);
            }
            if(operator.equalsIgnoreCase("=")){
                System.out.println("Result: " + temp);
                return;
            }
//            switch (operator) {
//                case "+":
//                    temp += enterNumber();
//                    System.out.println("Memory: " + temp);
//                    continue;
//                case "-":
//                    temp -= enterNumber();
//                    System.out.println("Memory: " + temp);
//                    continue;
//                case "*":
//                    temp *= enterNumber();
//                    System.out.println("Memory: " + temp);
//                    continue;
//                case "/":
//                    temp /= enterNumber();
//                    System.out.println("Memory: " + temp);
//                    continue;
//                case "^":
//                    temp = Math.pow(temp, enterNumber());
//                    System.out.println("Memory: " + temp);
//                    continue;
//                case "=":
//                    System.out.println("Result: " + temp);
//                    break;
//            }
        }
    }
    
    public static void calculatorBMI() {
        System.out.print("Enter Weight(kg): ");
        double weight = Validation.checkBMI();
        System.out.print("Enter Height(cm): ");
        double height = Validation.checkBMI();
        double bmi = weight*10000 / (height*height);
        System.out.printf("BMI number: %.2f\n", bmi);
        System.out.println("BMI Status: " + Validation.bmiStatus(bmi));
    }
    
    public void execute(){
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    normalCalculator();
                    break;
                case 2:
                    calculatorBMI();
                    break;
                case 3: 
                    System.exit(0); 
            }
        }    
    }
}


