/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package random_array_class;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class RandomArray {

    public static Scanner sc = new Scanner(System.in);
    
    public static int getSize(){
        System.out.println("Enter number of array: ");
        int size = checkValueOfSize();
        return size;
    }
    
    public static int checkValueOfSize(){
        while(true){            
            try{
                Integer size = null;
                String intSize = sc.nextLine();
                size = new Integer(intSize);
                if(size>0)
                    return size;
                else
                    System.out.println("Please input positive number!");
            } 
            catch(NumberFormatException e){
                System.err.println("Please input number!");
                System.out.println("Please enter again: "); 
            }
        }       
    }
    
    static int [] randomValue(int size){
        int a[] = new int[size];
        Random rd = new Random();
        System.out.print("The array: ");
        System.out.print("[");
        for(int i = 0; i < a.length; i++){ 
            a[i] = rd.nextInt(50);
            System.out.print(a[i]);
            if(i < a.length - 1)
                System.out.print(", ");
        }
        System.out.print("]");
        return a;
    }
    
    public static void main(String[] args) {
        randomValue(getSize());
    }
    
}
