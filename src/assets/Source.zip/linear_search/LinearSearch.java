/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package linear_search;

import java.util.Scanner;
import java.util.Random;

public class LinearSearch {
    static int getSize(){
        System.out.println("Enter number of array: ");
        int size = checkValueOfSize();
        return size;
    }
    static int checkValueOfSize(){
        Scanner sc = new Scanner (System.in);
        while(true){            
            try{
                Integer size = null;
                String intSize = sc.nextLine();
                size = new Integer(intSize);
                if(size>0)
                    return size;
                else
                    System.out.println("Please input positive number!");
            } 
            catch(NumberFormatException e){
                System.err.println("Please input number!");
                System.out.println("Please enter again: "); 
            }
        }       
    }
    static int [] randomValue(int a[]){
        Random rd = new Random();
        System.out.print("The array: ");
        System.out.print("[");
        for(int i = 0; i < a.length; i++){ 
            a[i]=rd.nextInt(20);
            System.out.print(a[i]);
            if(i < a.length - 1)
                System.out.print(", ");
        }
        System.out.print("]");
        return a;
    }
    static int searchValue(){
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter search value: "); 
        int searchValue = sc.nextInt();
        return searchValue;
    }
    static int searchByLinearSearch(int a[], int searchValue){
        for(int i = 0; i < a.length; i++)
            if (a[i] == searchValue)
                return i;
        return -1;
    }
    static void printIndex(int searchValue, int foundIndex){
        if(foundIndex == -1)
            System.out.println("\nSearch value " + searchValue + " not found! ");   
        else
            System.out.println("\nFound " + searchValue + " at index: " + foundIndex);
    }
    
    public static void main(String[] args) {
        int size = getSize();
        int searchValue = searchValue();
        int a[] = new int[size];
        randomValue(a);
        printIndex(searchValue, searchByLinearSearch(a, searchValue));
    }
    
}
