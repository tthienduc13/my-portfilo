/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package solving_the_equation_find_the_square_numbers_even_numbers_and_odd_numbers;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    private List<String> choices = Arrays.asList("\n========= Equation Program =========",
                                                 "1. Calculate Superlative Equation",
                                                 "2. Calculate Quadratic Equation",
                                                 "3. Exit",
                                                 "Please choice one option: ");
    
    public int getChoice() {
        Scanner sc = new Scanner(System.in);
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 3);
    }
    
    public void calculateSuperlativeEquation(){
        System.out.println();
        System.out.println("----- Calculate Superlative Equation -----");
        System.out.println("Enter A: ");
        double a = Validation.checkInputDouble();
        System.out.println("Enter B: ");
        double b = Validation.checkInputDouble();
        double solution = -b / a;
        System.out.println("Solution: x = " + solution);
        check3Value(a, b, solution);
    }
    
    public void calculateQuadraticEquation(){
        System.out.println();
        System.out.println("----- Calculate Quadratic Equation -----");
        System.out.println("Enter A: ");
        double a = Validation.checkInputDouble();
        System.out.println("Enter B: ");
        double b = Validation.checkInputDouble();
        System.out.println("Enter C: ");
        double c = Validation.checkInputDouble();
        if(a == 0){
            if(b == 0){
                System.out.println("The equation hasn't solution!");
                check3Value(a, b, c);
            }
            else{
                double solution = -c / b;
                System.out.println("Solution: x = " + solution);
                check4Value(a, b, c, solution);
            }
            return;
        }
        double delta = b * b - 4 * a * c;
        if(delta > 0){
            double x1 = (-b + Math.sqrt(delta)) / (2 * a);
            double x2 = (-b - Math.sqrt(delta)) / (2 * a);
            System.out.println("Solution: x1 = " + x1 + " and " + x2);
            check5Value(a, b, c, x1, x2);
        }
        else if (delta == 0){
            double x1 = -b / (2 * a);
            System.out.println("Equation with double roots!");
            System.out.println("Solution: x1 = x2 = " + x1);
            check4Value(a, b, c, x1);
        }
        else{
            System.out.println("The equation hasn't solution!");
                check3Value(a, b, c);
        }
            
    }
    
        public void check3Value(double a, double b, double c){
        System.out.print("Number is Odd: ");
        if(Validation.isOdd(a))
            System.out.print(a + ", ");
        if(Validation.isOdd(b))
            System.out.print(b + ", ");
        if(Validation.isOdd(c))
            System.out.print(c + ", ");
        System.out.print("Number is Even: ");
        if(Validation.isEven(a))
            System.out.print(a + ", ");
        if(Validation.isEven(b))
            System.out.print(b + ", ");
        if(Validation.isEven(c))
            System.out.print(c + ", ");
        System.out.print("Number is Perfect Square: ");
        if(Validation.checkSquareNumber(a))
            System.out.print(a + ", ");
        if(Validation.checkSquareNumber(b))
            System.out.print(b + ", ");
        if(Validation.checkSquareNumber(c))
            System.out.print(c + ", ");
    }
    
    public void check4Value(double a, double b, double c, double d){
        System.out.print("Number is Odd: ");
        if(Validation.isOdd(a))
            System.out.print(a + ", ");
        if(Validation.isOdd(b))
            System.out.print(b + ", ");
        if(Validation.isOdd(c))
            System.out.print(c + ", ");
        if(Validation.isOdd(d))
            System.out.print(d + ", ");
        System.out.print("Number is Even: ");
        if(Validation.isEven(a))
            System.out.print(a + ", ");
        if(Validation.isEven(b))
            System.out.print(b + ", ");
        if(Validation.isEven(c))
            System.out.print(c + ", ");
        if(Validation.isEven(d))
            System.out.print(d + ", ");
        System.out.print("Number is Perfect Square: ");
        if(Validation.checkSquareNumber(a))
            System.out.print(a + ", ");
        if(Validation.checkSquareNumber(b))
            System.out.print(b + ", ");
        if(Validation.checkSquareNumber(c))
            System.out.print(c + ", ");
        if(Validation.checkSquareNumber(d))
            System.out.print(d + ", ");
    }
    
    public void check5Value(double a, double b, double c, double d, double e){
        System.out.print("Number is Odd: ");
        if(Validation.isOdd(a))
            System.out.print(a + ", ");
        if(Validation.isOdd(b))
            System.out.print(b + ", ");
        if(Validation.isOdd(c))
            System.out.print(c + ", ");
        if(Validation.isOdd(d))
            System.out.print(d + ", ");
        if(Validation.isOdd(e))
            System.out.print(e + ", ");
        System.out.print("Number is Even: ");
        if(Validation.isEven(a))
            System.out.print(a + ", ");
        if(Validation.isEven(b))
            System.out.print(b + ", ");
        if(Validation.isEven(c))
            System.out.print(c + ", ");
        if(Validation.isEven(d))
            System.out.print(d + ", ");
        if(Validation.isEven(e))
            System.out.print(e + ", ");
        System.out.print("Number is Perfect Square: ");
        if(Validation.checkSquareNumber(a))
            System.out.print(a + ", ");
        if(Validation.checkSquareNumber(b))
            System.out.print(b + ", ");
        if(Validation.checkSquareNumber(c))
            System.out.print(c + ", ");
        if(Validation.checkSquareNumber(d))
            System.out.print(d + ", ");
        if(Validation.checkSquareNumber(e))
            System.out.print(e + ", ");
    }
    
    public void execute() {
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    calculateSuperlativeEquation();
                    break;
                case 2:
                    calculateQuadraticEquation();
                    break;
                case 3: 
                    System.exit(0); 
            }
        }
     }
}
