/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fraction;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class Validation {

    public static Scanner sc = new Scanner(System.in);
    public static Random rd = new Random();
    
    public static int checkValueOfElement(){
        Scanner sc = new Scanner (System.in);
        while(true){            
            try{
                Integer element = null;
                String intElement = sc.nextLine();
                element = new Integer(intElement);
                if(element > 0)
                    return element;
                else
                    System.err.println("Please input a positive integer number!");
                    System.out.println("Please enter again: ");
            } 
            catch(NumberFormatException e){
                System.err.println("Please input a integer number!");
                System.out.println("Please enter again: "); 
            }
        }       
    }
    
    public static int getElement(){
        System.out.println("Enter the number of element: ");
        int element = checkValueOfElement();
        return element;
    }
    
}
