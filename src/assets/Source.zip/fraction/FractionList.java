/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fraction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author MSI GL63
 */
public class FractionList {
    
    private ArrayList<Fraction> fractionList = new ArrayList<>();

    public FractionList() {}
    
    public FractionList(ArrayList<Fraction> fractionList) {
        this.fractionList = fractionList;
    }

    public ArrayList<Fraction> getFractionList() {
        return fractionList;
    }

    public void setFractionList(ArrayList<Fraction> fractionList) {
        this.fractionList = fractionList;
    }
    
    public void randomFraction(int element){
        Random rd = new Random();
        for (int i = 0; i < element; i++) {
            Fraction f = new Fraction();
            f.setNumerator(rd.nextInt(10));
            f.setDenominator(rd.nextInt(10) + 1);
            fractionList.add(f);
        }
    }
    
    public ArrayList<Fraction> sortFraction(ArrayList<Fraction> result){
        Collections.sort(result,(f1, f2) -> {
            return Double.compare((double) f1.getNumerator() / f1.getDenominator(), (double) f2.getNumerator() / f2.getDenominator());
        });  
        return result;
    }
    
    public int findGCD(int n, int d){
        if(d == 0)
            return n;
        else
            return findGCD(d, Math.abs(n - d));
    }
    
    public Fraction minimalFraction(Fraction fraction){
        Fraction f = new Fraction();
        f.setNumerator(fraction.getNumerator() / findGCD(fraction.getNumerator(),fraction.getDenominator()));
        f.setDenominator(fraction.getDenominator() / findGCD(fraction.getNumerator(),fraction.getDenominator()));
        return f;
    }
    
    public void minimalFractionList(){
        for (Fraction f : fractionList) {
            f.setNumerator(minimalFraction(f).getNumerator());
            f.setDenominator(minimalFraction(f).getDenominator());
        }
    }
    
    public Fraction addFraction(Fraction f1, Fraction f2){
        Fraction f = new Fraction();
        f.setNumerator(f1.getNumerator() * f2.getDenominator() + f2.getNumerator() * f1.getDenominator());
        f.setDenominator(f1.getDenominator() * f2.getDenominator());
        return f;
    } 
    
    public Fraction sumFraction(){
        Fraction f = new Fraction();
        f.setNumerator(fractionList.get(0).getNumerator());
        f.setDenominator(fractionList.get(0).getDenominator());
        for (int i = 1; i < fractionList.size(); i++) {
            f = addFraction(f, fractionList.get(i));
        }
        return f;
    }
    
    public void printListFraction(){
        System.out.println(fractionList.toString());
    }
  
}
