/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fraction;

/**
 *
 * @author MSI GL63
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FractionList fractionList = new FractionList();
        fractionList.randomFraction(Validation.getElement());
        fractionList.minimalFractionList();
        fractionList.sortFraction(fractionList.getFractionList());
        if(!fractionList.getFractionList().isEmpty()){
            System.out.println("Sorted fraction list: ");
            fractionList.printListFraction();
        }
        else
            System.err.println("Fraction list is empty!");
        System.out.println("Sum of fractions: ");
        System.out.println(fractionList.minimalFraction(fractionList.sumFraction()));
        }
        
    }
    
