/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fraction;

/**
 *
 * @author MSI GL63
 */

import java.util.Random;
import java.util.Scanner;

public class Fraction /*implements Comparable<Fraction> */{
    
    private int numerator; 
    private int denominator;

    public Fraction() {
        numerator = 0;
        denominator = 1;
    }

    public Fraction(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
    }

    public int getNumerator() {
        return numerator;
    }
    
    public int getDenominator() {
        return denominator;
    }

    public void setNumerator(int numerator) {
        this.numerator = numerator;
    }

    public void setDenominator(int denominator) {
        this.denominator = denominator;
    }

    @Override
    public String toString() {
        return this.numerator + "/" + this.denominator;
    }

//    @Override
//    public int compareTo(Fraction o) {
//        float temp = Math.abs((float)numerator/denominator - (float)o.numerator/o.denominator);
//        if (temp < 0)
//            return -1;
//        if(temp < 1e-9)
//            return 0;
//        return 1;
//    }
    
}
