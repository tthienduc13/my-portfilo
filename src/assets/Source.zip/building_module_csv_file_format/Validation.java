/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package building_module_csv_file_format;

import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class Validation {
    
    public static Scanner sc = new Scanner(System.in);
    
    public static int checkInputInteger(){
        while(true){            
            try{
                Integer input = null;
                String intInput = sc.nextLine();
                input = new Integer(intInput);
                if(input > 0)
                    return input;
                else
                    System.err.println("Please input a positive integer number!");
                    System.out.println("Please enter again: ");
            } 
            catch(NumberFormatException e){
                System.err.println("Please input a integer number!");
                System.out.println("Please enter again: "); 
            }
        }       
    }
    
    public static int checkInputIntLimit(int min, int max) {
        while(true){
            try{
                int input = checkInputInteger();
                if (input < min || input > max)
                    throw new NumberFormatException();
                return input;
            } 
            catch(NumberFormatException e){
                System.err.println("Please input number in rage [" + min + ", " + max + "]!");
                System.out.print("Please enter again: ");
            }
        }
    }
    
    public static String checkInputString(){
        while(true){
            String input = sc.nextLine();
            if(input.isEmpty()){
                System.err.println("Please input a string!");
                System.out.println("Please enter again: ");
            }
            else
                return input;
        }
    }
    
}
