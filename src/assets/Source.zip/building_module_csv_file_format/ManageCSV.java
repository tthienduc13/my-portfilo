/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package building_module_csv_file_format;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author MSI GL63
 */
public class ManageCSV {
    
    private ArrayList<CSV> csvArrayList = new ArrayList<>();

    public ManageCSV() {}
    
    public ManageCSV(ArrayList<CSV> csvArrayList){
        this.csvArrayList = csvArrayList;
    }

    public ArrayList<CSV> getCsvArrayList() {
        return csvArrayList;
    }

    public void setCsvArrayList(ArrayList<CSV> csvArrayList) {
        this.csvArrayList = csvArrayList;
    }
    
    public void importCSV(){
        String line = "";
        String path = Validation.checkInputString();
        BufferedReader br = null;
        try {
//            Dung file
//            File f = new File(path);
//            if (f.exists() && f.isFile()) { 
                FileReader fr = new FileReader(path);
                br = new BufferedReader(fr);
                while((line = br.readLine()) != null){
                    String [] CSV = line.split(",");   
                    CSV csv = new CSV(CSV[0], CSV[1], CSV[2], CSV[3], CSV[4]);
                    csvArrayList.add(csv);
                }
                System.out.println("Import: Done");
//            }
//            else 
//                System.err.println("This path isn't file!");
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e){
            e.printStackTrace();
        }
        finally {
            if(br != null){
                try {
                    br.close();
                } 
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    public void formatName(){
        for (int i = 0; i < csvArrayList.size(); i++) {
            String name = csvArrayList.get(i).getName().toLowerCase().replaceAll("\\s+", " ");
            String [] nameCSV = name.split(" ");
            StringBuffer sb = new StringBuffer();
            for (int j = 0; j < nameCSV.length; j++)
                sb.append(Character.toUpperCase(nameCSV[j].charAt(0))).append(nameCSV[j].substring(1)).append(" ");
            csvArrayList.get(i).setName(sb.toString().trim());
        }
        System.out.println("Format: Done");
    }
    
    public void formatAddress(){
        for (CSV c : csvArrayList)
            c.setAddress(c.getAddress().replaceAll("\\s+", " ").trim());
        System.out.println("Format: Done");
    }

    public  void exportFile(){
        String path = Validation.checkInputString();
        FileWriter fw = null;
        try {
            fw = new FileWriter(path);
            // FileWritter(String path)
            for (CSV csv : csvArrayList) {
                fw.append(String.valueOf(csv.getId()));
                fw.append(",");
                fw.append(String.valueOf(csv.getName()));
                fw.append(",");
                fw.append(String.valueOf(csv.getEmail()));
                fw.append(",");
                fw.append(String.valueOf(csv.getPhone()));
                fw.append(",");
                fw.append(String.valueOf(csv.getAddress()));
                fw.append(",");
                fw.append("\n");
            }
            System.out.println("Export: Done");
        } 
        catch (IOException e) {
            e.printStackTrace();
        } 
        finally {
            try {
                fw.flush();
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
}
