/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package book_management;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    ManageBook manageBook = new ManageBook();
    
    private List<String> choices = Arrays.asList("====== Book Management ======",
                                                "1. Import Book Information",
                                                "2. Add Book",
                                                "3. Search",
                                                "4. Delete",
                                                "5. Export To CSV File",
                                                "6. Exit",
                                                "==============================",
                                                "Please choice one option: ");
    
    public int getChoice() {
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 6);
    }
    
    public void importBookInfor(){
        System.out.println("------ Import CSV ------");
        System.out.println("Enter path: ");
        manageBook.importBookInfor();
    }
    
    public void addBook(){
        Book book = new Book();
        System.out.println("------- Add -------");
        System.out.println("Enter book id: ");
        book.setBookId(Validation.checkInputString());
        System.out.println("Enter book name: ");
        book.setBookName(Validation.checkInputString());
        System.out.println("Enter issue number: ");
        book.setIssueNumber(Validation.checkInputString());
        System.out.println("Enter author name: ");
        book.setAuthorName(Validation.checkInputString());
        manageBook.addBookInfor(book);
        System.out.println("Add: Done");
    }
    
    public void searchBook(){
        System.out.println("------ Search ------");
        if(!manageBook.getBooksArrayList().isEmpty()){
            System.out.println("Enter book name: ");
            String bookName = Validation.checkBookNameExist(manageBook.getBooksArrayList());
            System.out.printf("%-10s%-30s%-30s%-15s\n", "Book ID", "Book Name", "Author Name", "Issue Number");
            for (Book b : manageBook.searchBookName(bookName)) {
                System.out.printf("%-10s%-30s%-30s%-15s\n", b.getBookId(), b.getBookName(), b.getAuthorName(), b.getIssueNumber());
            }
            System.out.println("Search: Done");
        }
        else
            System.err.println("No data to search!\n");
    }
    
    public void deleteBook(){
        System.out.println("------ Delete ------");
        if(!manageBook.getBooksArrayList().isEmpty()){
            System.out.println("Enter book id: ");
            manageBook.deleteBook(Validation.checkIdExist(manageBook.getBooksArrayList()));
            System.out.printf("%-10s%-30s%-30s%-15s\n", "Book ID", "Book Name", "Author Name", "Issue Number");
            for (Book b : manageBook.getBooksArrayList()) {
                System.out.printf("%-10s%-30s%-30s%-15s\n", b.getBookId(), b.getBookName(), b.getAuthorName(), b.getIssueNumber());
            }
            System.out.println("Delete: Done");
        }
        else
            System.err.println("No data to delete!\n");
    }
    
    public void exportFileCSV(){
        System.out.println("------ Export CSV ------");
        System.out.println("Enter path: ");
        manageBook.exportFileCSV();
    }
    
    public void execute() {
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    importBookInfor();
                    break;
                case 2:
                    addBook();
                    break;
                case 3:
                    searchBook();
                    break;
                case 4: 
                    deleteBook();
                    break;
                case 5: 
                    exportFileCSV();
                    break;
                case 6: 
                    System.exit(0); 
            }
        }
    }
    
}
