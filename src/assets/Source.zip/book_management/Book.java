/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package book_management;

/**
 *
 * @author MSI GL63
 */
public class Book {
    
    private String bookId;
    private String bookName;
    private String authorName;
    private String issueNumber; 

    public Book() {}

    public Book(String bookId, String bookName, String authorName, String issueNumber) {
        this.bookId = bookId;
        this.bookName = bookName;
        this.authorName = authorName;
        this.issueNumber = issueNumber;
    }  

    public String getBookId() {
        return bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getIssueNumber() {
        return issueNumber;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public void setIssueNumber(String issueNumber) {
        this.issueNumber = issueNumber;
    }
    
    
}
