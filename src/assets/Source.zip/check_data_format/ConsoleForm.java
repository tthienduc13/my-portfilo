/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package check_data_format;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    private List<String> choices = Arrays.asList("===== Validate Program =====",
                                                 "1. Check Phone",
                                                 "2. Check Email",
                                                 "3. Check Date",
                                                 "4. Exit",
                                                 "============================",
                                                 "Enter your choice: ");
    
    public int getChoice() {
        Scanner sc = new Scanner(System.in);
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 4);
    }
    
    public void checkPhone(){
        while (true){
            Scanner sc = new Scanner(System.in);
            System.out.println("---------- Check Phone ----------");
            System.out.println("Enter Phone Number: ");
            String phone = Validation.checkInputPhone();
            System.err.println("Successful!"); 
            System.out.println("Do you want to continue: ");
            if(Validation.checkInputYN() == false)
                break;
        }
    }
    
    public void checkEmail(){
        while (true){
            Scanner sc = new Scanner(System.in);
            System.out.println("---------- Check Email ----------");
            System.out.println("Enter Email: ");
            String email = Validation.checkInputEmail();
            System.err.println("Successful!"); 
            System.out.println("Do you want to continue: ");
            if(Validation.checkInputYN() == false)
                break;
        }    
    }
    
    public void checkDate(){
        while (true){
            Scanner sc = new Scanner(System.in);
            System.out.println("---------- Check Date ----------");
            System.out.println("Enter Date: ");
            String date = Validation.checkInputDate();
            System.err.println("Successful!"); 
            System.out.println("Do you want to continue: ");
            if(Validation.checkInputYN() == false)
                break;
        }  
    }
    
    public void execute() {
        while (true) {
            int choice = getChoice();
            switch (choice) {
                case 1:
                    checkPhone();
                    break;
                case 2:
                    checkEmail();
                    break;
                case 3:
                    checkDate();
                    break;
                case 4:
                    System.exit(0);
            }
        }
    }
}
