/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package check_data_format;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class Validation {
    
    public static Scanner sc = new Scanner(System.in);
    private static String VALID_PHONE = "^[0-9]{10}$";
//  private static String VALID_PHONE = "^0[0-9]{9}$";
//  SÐT Viet Nam
    private static String VALID_EMAIL = "^[a-zA-Z][\\w._%+-]+@[a-zA-Z]{2,}+(\\.[a-zA-Z]+){1,3}$";
    //Not valid: <account name>.@domain.com
    //           .<account . name>@domain.com
    //           <account-name>@domain.com.
    //           <account name>@.com
    
    
    public static String checkInputString(){
        while(true){
            String input = sc.nextLine();
            if(input.isEmpty()){
                System.err.println("Please input a string!");
                System.out.println("Please enter again: ");
            }
            else
                return input;
        }
    }
   
    public static String checkInputPhone(){
        while(true){
            try {
                String input = checkInputString();
                if(input.matches(VALID_PHONE))
                    return input;
                else{
                    System.err.println("Phone number must be 10 digits!");
                    System.out.print("Please enter again: ");
                }
            } 
            catch (NumberFormatException e) {
                System.err.println("Phone number must is number!");
                System.out.println("Please enter again: "); 
            }
        }    
    }
    
    public static String checkInputEmail(){
        while(true){
                String input = checkInputString();
                if(input.matches(VALID_EMAIL))
                    return input;
                else{
                    System.err.println("Email must be correct format!");
                    System.out.print("Please enter again: ");
                }
        }    
    }
    
    public static String checkInputDate(){
        while(true){            
            String input = checkInputString();
            SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
            try {
                date.setLenient(false);
                date.parse(input);
                return input;
                
            }   
            catch (ParseException ex) {
                System.err.println("Date to correct format(dd/mm/yyyy)");
                System.out.print("Please enter again: ");
            }
        }
    }
    
    public static int checkInputInteger(){
        Scanner sc = new Scanner (System.in);
        while(true){            
            try{
                Integer input = null;
                String intInput = sc.nextLine();
                input = new Integer(intInput);
                if(input > 0)
                    return input;
                else
                    System.err.println("Please input a positive integer number!");
                    System.out.println("Please enter again: ");
            } 
            catch(NumberFormatException e){
                System.err.println("Please input a integer number!");
                System.out.println("Please enter again: "); 
            }
        }       
    }
    
    public static int checkInputIntLimit(int min, int max) {
        while(true){
            try{
                int input = checkInputInteger();
                if (input < min || input > max)
                    throw new NumberFormatException();
                return input;
            } 
            catch(NumberFormatException e){
                System.err.println("Please input number in rage [" + min + ", " + max + "]!");
                System.out.print("Please enter again: ");
            }
        }
    }
    
    public static boolean checkInputYN(){
        while (true) {
            String inputString = checkInputString();
            if (inputString.equalsIgnoreCase("Y")) 
                return true;
            else if (inputString.equalsIgnoreCase("N")) 
                return false;
            else{
                System.err.println("Please input Y/y or N/n!");
                System.out.print("Please enter again: ");
            }
        }
    }
    
}
