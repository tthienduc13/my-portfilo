/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package analyze_the_user_input_string;

import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class Validation {
    
    public static Scanner sc = new Scanner(System.in);
    
    public static boolean checkSquareNumber(int n){
        if((int)Math.pow(n, 2) == n)
         return true;
        return false;
    }
    
    public static String checkInputString(){
        while(true){
            String input = sc.nextLine();
            if(input.isEmpty()){
                System.err.println("Please input a string!");
                System.out.println("Please enter again: ");
            }
            else
                return input;
        }
    }
    
    
}
