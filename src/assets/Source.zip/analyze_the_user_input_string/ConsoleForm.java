/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package analyze_the_user_input_string;

import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    ManageAnalyzeString analyzeString = new ManageAnalyzeString();
    
    public void execute(){
        Scanner sc = new Scanner(System.in);
        System.out.println("===== Analysis String program ====");
        System.out.println("Input String: ");
        String input = sc.nextLine();
        analyzeString.getNumber(input);
        analyzeString.getCharacter(input);
        System.out.println("-----Result Analysis------");
        for (Map.Entry m : analyzeString.numberHashMap.entrySet()) {
            System.out.println(m.getKey() + " " + m.getValue());
        }
        for (Map.Entry m : analyzeString.charHashMap.entrySet()) {
            System.out.println(m.getKey() + " " + m.getValue());
        }
    }
}
