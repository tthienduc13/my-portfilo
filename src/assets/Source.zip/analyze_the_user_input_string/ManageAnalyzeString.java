/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package analyze_the_user_input_string;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author MSI GL63
 */
public class ManageAnalyzeString {
    
    HashMap<String, ArrayList<Integer>> numberHashMap = new HashMap<>();
    HashMap<String, String> charHashMap = new HashMap<>();

    public ManageAnalyzeString() {}
    
    public ManageAnalyzeString(HashMap<String, ArrayList<Integer>> numberHashMap, HashMap<String, String> charHashMap){
        this.numberHashMap = numberHashMap;
        this.charHashMap = charHashMap;
    }

    public HashMap<String, ArrayList<Integer>> getNumberHashMap() {
        return numberHashMap;
    }

    public void setNumberHashMap(HashMap<String, ArrayList<Integer>> numberHashMap) {
        this.numberHashMap = numberHashMap;
    }

    public HashMap<String, String> getCharHashMap() {
        return charHashMap;
    }

    public void setCharHashMap(HashMap<String, String> charHashMap) {
        this.charHashMap = charHashMap;
    }
    
    public void getNumber(String inputString){
        String number = inputString.replaceAll("\\D+", "_");
        if(number.charAt(0) == '_')
            number = number.substring(1);
        if(number.charAt(number.length() - 1) == '_')
            number = number.substring(0, number.length() - 1);
        String [] temp = number.split("_");
        ArrayList<Integer> listAll = new ArrayList<>();
        ArrayList<Integer> listEven = new ArrayList<>();
        ArrayList<Integer> listOdd = new ArrayList<>();
        ArrayList<Integer> listSquare = new ArrayList<>();
        for (int i = 0; i < temp.length; i++) {
            int check = Integer.parseInt(temp[i]);
            //convert int => calculate / getNumber
            if(check % 2 == 1)
                listOdd.add(check);
            if(check % 2 == 0)
                listEven.add(check);
            if(Validation.checkSquareNumber(check))
                listSquare.add(check);
            listAll.add(check);
        }
        numberHashMap.put("Perfect Square Numbers: ", listSquare);
        numberHashMap.put("Odd Numbers: ", listOdd);
        numberHashMap.put("Even Numbers: ", listEven);
        numberHashMap.put("All Numbers: ", listAll);        
    }
    
    public void getCharacter(String inputString){
        String uppercaseChar = inputString.replaceAll("\\W*[0-9]*[a-z]*", "");
        // - special, digit, lowercase
        String lowercaseChar = inputString.replaceAll("\\W*[0-9]*[A-Z]*", "");
        // - special, digit, uppercase
        String specialChar = inputString.replaceAll("\\w", "");
        // - lowercase, uppercase, digit
        String allChar = inputString.replaceAll("[0-9]", "");
        charHashMap.put("Uppercase Characters: ", uppercaseChar);
        charHashMap.put("Lowercase Characters:", lowercaseChar);
        charHashMap.put("Special Characters: ", specialChar);
        charHashMap.put("All Characters: ", allChar);
    }   
}
