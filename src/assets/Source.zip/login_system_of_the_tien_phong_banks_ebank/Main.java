/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package login_system_of_the_tien_phong_banks_ebank;

import java.util.Locale;

/**
 *
 * @author MSI GL63
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Manage manage = new Manage();
        Locale vi = new Locale("vi");
        Locale en = new Locale("en");
        while (true) {            
            switch(ConsoleForm.getChoice()){
                case 1: 
                    manage.login(vi);
                    break;
                case 2:
                    manage.login(en);
                    break;
                case 3: 
                    return;
            }
        }
    }
    
}
