/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package login_system_of_the_tien_phong_banks_ebank;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    Manage manage = new Manage();
    
    private static List<String> choices = Arrays.asList("===== Login Program =====",
                                                "1. Vietnamese",
                                                "2. English",
                                                "3. Exit",
                                                "========================================",
                                                "Please choice one option: ");
    
    public static int getChoice() {
        Scanner sc = new Scanner(System.in);
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1,3);
    }
}
