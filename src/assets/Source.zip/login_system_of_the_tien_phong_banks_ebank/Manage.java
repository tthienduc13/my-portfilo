/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package login_system_of_the_tien_phong_banks_ebank;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class Manage {
    
    public static Scanner sc = new Scanner(System.in);
    public static final String ACCOUNT_NUMBER_VALID = "^\\d{10}$";  
    public static char[] CAPTCHA_CODE = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        'A', 'a', 'B', 'b', 'C', 'c', 'D', 'd', 'E', 'e', 'F', 'f', 'G', 'g', 'H', 'h', 'I', 'i',
        'J', 'j', 'K', 'k', 'L', 'l', 'M', 'm', 'N', 'n', 'O', 'o', 'P', 'p', 'Q', 'q', 'R', 'r', 
        'S', 's', 'T', 't', 'U', 'u', 'V', 'v', 'W', 'w', 'X', 'x', 'Y', 'y', 'Z', 'z'};
    
    private Locale locale;
        
    public Locale getLocale() {
        return locale;
    }
    
    public void setLocale(Locale locale) {
        this.locale = locale;
    }
    
    public String getMessages(String key){ 
        ResourceBundle mess = ResourceBundle.getBundle("mess", locale);
        return mess.getString(key);
    }
    
    public void login(Locale locale){
        setLocale(locale);
        checkInputAccount();
        checkInputPassword();
        checkInputLogin();
    }

    public String checkInputString(){
        while(true){
            String input = sc.nextLine();
            if(input.isEmpty()){
                System.out.println(getMessages("errCheckInputString"));
                System.out.println();
            }
            else
                return input;
        }
    }
    
    public String checkInputAccount(){
        while(true){
            System.out.println(getMessages("account"));
            String input = checkInputString();
            if(input.matches(ACCOUNT_NUMBER_VALID))
                return input;
            else{
                System.out.println(getMessages("errCheckInputAccount"));
                System.out.println();
                }
        }    
    }
    
    public boolean checkValidPassword(String password){
        int countDigit = 0;
        int countLetter = 0;
        if(password.length() < 8 || password.length() > 31){
            System.out.println(getMessages("errCheckValidPassword"));
            System.out.println();
            return false;
        }
        else{
            for (int i = 0; i < password.length(); i++) {
                if(Character.isDigit(password.charAt(i)))
                    countDigit++;
                else if(Character.isLetter(password.charAt(i)))
                    countLetter++;
            }
            if(countDigit == 0 || countLetter == 0){
                System.out.println(getMessages("errCheckValidPassword"));
                System.out.println();
                return false;
            }
        }
        return true;
    }
    
    public String checkInputPassword(){
        while(true){
            System.out.println(getMessages("password"));
            String input = checkInputString();
            if(checkValidPassword(input))
                    return input;
        }   
    }
    
    public String createRandomCaptcha(){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            int index = (int)(Math.random() * (CAPTCHA_CODE.length));
            sb.append(CAPTCHA_CODE[index]);
        }
        return sb.toString();
    }
    
    public boolean checkInputCaptcha(String captcha){
        String captchaInput = checkInputString();
        if(!captcha.equals(captchaInput))
            return false;
        return true;
    }
    
    public void checkInputLogin(){
        while (true) {  
            System.out.print(getMessages("inputCaptcha"));
            String captcha = createRandomCaptcha();
            System.out.println(captcha);
            if(checkInputCaptcha(captcha)){
                System.out.println(getMessages("loginSuccess"));
                System.out.println();
                return;
            }
            else{
                System.out.println(getMessages("errCheckInputCaptcha"));
                System.out.println();
            }
        }
    }
}
