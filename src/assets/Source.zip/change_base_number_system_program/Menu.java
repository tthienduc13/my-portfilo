/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package change_base_number_system_program;

/**
 *
 * @author MSI GL63
 */
public class Menu {
    public static int getChoice(){
        System.out.println("--------- MENU ---------");
        System.out.println("1. Convert From Binary.");
        System.out.println("2. Convert From Decimal.");
        System.out.println("3. Convert From Hexa.");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
        int choice = Validation.checkInputLimit(1, 4);
        return choice;
    }
    public static void menu(){
        while(true){
            int choice = getChoice();
            switch(choice){
                case 1:
                    ManagerConvert.convertFromBinary(Validation.checkInputBinary());
                    break;
                case 2:
                    ManagerConvert.convertFromDecimal(Validation.checkInputDecimal());
                    break;
                case 3:
                    ManagerConvert.convertFromHexa(Validation.checkInputHexa());
                    break;
                case 4:
                    return;
            }
        }
    }    
}
