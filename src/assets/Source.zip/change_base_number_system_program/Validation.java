/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package change_base_number_system_program;

import java.util.Scanner;

public class Validation {
    
    public static Scanner sc = new Scanner(System.in);
    public static final String BINARY_VALID = "[0-1]*";
    public static final String DECIMAL_VALID = "[0-9]*";
    public static final String HEXA_VALID = "[0-9A-Fa-f]*";
    
    public static int checkInputLimit(int min, int max) {
        while(true){
            try{
                int input = Integer.parseInt(sc.nextLine());
                if (input < min || input > max)
                    throw new NumberFormatException();
                return input;
            } 
            catch(NumberFormatException e){
                System.err.println("Please input number in rage [" + min + ", " + max + "]!");
                System.out.print("Please enter again: ");
            }
        }
    }
    public static String checkInputBinary() {
        System.out.print("Enter number binary: ");
        String input;
        while(true){
            input = sc.nextLine();
            if(input.matches(BINARY_VALID))
                return input;
            System.err.println("Please enter 0 or 1!");
            System.out.print("Enter again: ");
        }
    }
    public static String checkInputDecimal() {
        System.out.print("Enter number decimal: ");
        String input;
        while(true){
            input = sc.nextLine();
            if(input.matches(DECIMAL_VALID))
                return input;
            System.err.println("Please enter 0 - 9!");
            System.out.print("Enter again: ");
        }
    }
    public static String checkInputHexa() {
        System.out.print("Enter number hexadecimal: ");
        String input;
        while(true){
            input = sc.nextLine();
            if(input.matches(HEXA_VALID))
                return input;
            System.err.println("Please enter 0 - 9  A - F!");
            System.out.print("Enter again: ");
        }
    }
}
 