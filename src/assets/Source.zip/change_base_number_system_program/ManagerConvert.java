/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package change_base_number_system_program;

/**
 *
 * @author MSI GL63
 */
public class ManagerConvert {
    
    public static final char[] hexaDigits = {'0', '1', '2', '3', '4', '5', '6', '7','8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
    
    public static int displayConvert(String from, String case1, String case2){
        System.out.println("1. Convert form " + from + " to " + case1);
        System.out.println("2. Convert form " + from + " to " + case2);
        System.out.print("Enter your choice: ");
        int choice = Validation.checkInputLimit(1, 2);
        return choice;
    }
    public static void convertFromBinary(String binary) {
        int choice = displayConvert("binary", "decimal", "hexadecimal");
        switch(choice) {
            case 1:
                System.out.println("Decimal: " + convertBinaryToDecimal(binary));
                break;
            case 2:
                System.out.println("Hexadecimal: " + convertBinaryToHexa(binary));
                break;
        }
    }
    public static void convertFromDecimal(String decimal) {
        int choice = displayConvert("decimal", "binary", "hexadecimal");
        switch(choice) {
            case 1:
                System.out.println("Binary: " + convertDecimalToBinary(decimal));
                break;
            case 2:
                System.out.println("Hexadecimal: " + convertDecimalToHexa(decimal));
                break;
        }
    }
    public static void convertFromHexa(String hexa) {
        int choice = displayConvert("hexa", "binary", "decimal");
        switch(choice) {
            case 1:
                System.out.println("Binary: " + convertHexaToBinary(hexa));
                break;
            case 2:
                System.out.println("Decimal: " + convertHexaToDecimal(hexa));
                break;
        }
    }
    public static String convertBinaryToDecimal(String binary) {
        int decimal = Integer.parseInt(binary, 2);
        return Integer.toString(decimal);
    }
    public static String convertBinaryToHexa(String binary) {
        String decimal = convertBinaryToDecimal(binary);
        String hexa = convertDecimalToHexa(decimal);
        return hexa;
    }
    public static int convertHexaToDecimal(String hexa) {
        int decimal = Integer.parseInt(hexa, 16);
        return decimal;
    }
    public static String convertDecimalToBinary(String decimal) {
        String binary = Integer.toBinaryString(Integer.parseInt(decimal));
        return binary;
    }
    public static String convertHexaToBinary(String hexa) {
        String binary = Integer.toBinaryString(convertHexaToDecimal(hexa));
        return binary;
    }
    public static String convertDecimalToHexa(String decimal) {
        String hexa = "";
        int dec = Integer.parseInt(decimal);
        while(dec != 0){
            hexa = hexaDigits[dec % 16] + hexa;
            dec /= 16;
        }
        return hexa;
    }
}
