/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculate_the_sum_of_even_numbers;

import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class CalculateTheSumOfEvenNumbers {

    public static Scanner sc = new Scanner(System.in);
    
    public static int checkInputInteger(){
        while(true){            
            try{
                Integer input = null;
                String intInput = sc.nextLine();
                input = new Integer(intInput);
                if(input > 0)
                    return input;
                else
                    System.err.println("Please input a positive integer number!");
                    System.out.println("Please enter again: ");
            } 
            catch(NumberFormatException e){
                System.err.println("Please input a integer number!");
                System.out.println("Please enter again: "); 
            }
        }       
    }
    
    public static void main(String[] args) {
        System.out.println("Enter n :");
        int n = checkInputInteger();
        int result = 0;
        for(int i = 0; i < n; i++){
            if(i % 2 == 0)
                result += i;
        }
        System.out.println("The sum of even number less than " + n + ": " + result);
    }
    
}