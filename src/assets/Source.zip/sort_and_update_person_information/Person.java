package sort_and_update_person_information;

/**
 *
 * @author MSI GL63
 */
public class Person {

    private String code;
    private String name;
    private String address;
    private double salary;
    
    public Person() {
    }

    public Person(String code, String name, String address, double salary) {
        this.code = code;
        this.name = name;
        this.address = address;
        this.salary = salary;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public double getSalary() {
        return salary;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    
}
