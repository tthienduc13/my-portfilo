/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sort_and_update_person_information;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author MSI GL63
 */
public class ManagePerson {
    
    private ArrayList<Person> personsArrayList = new ArrayList<>();
    
    public ManagePerson(){}
    
    public ManagePerson(ArrayList<Person> personsArrayList){
        this.personsArrayList = personsArrayList;
    }

    public ArrayList<Person> getPersonsArrayList() {
        return personsArrayList;
    }

    public void setPersonsArrayList(ArrayList<Person> personsArrayList) {
        this.personsArrayList = personsArrayList;
    }
    
    public void importPersonInfor(){
        String line = "";
        String path = Validation.checkInputString();
        BufferedReader br = null;
        try {
//            Dung file
//            File f = new File(path);
//            if (f.exists() && f.isFile()) { 
            FileReader fr = new FileReader(path);
            br = new BufferedReader(fr);
            while((line = br.readLine()) != null){
                String [] persons = line.split(",");
                Person person = new Person(persons[0], persons[1], persons[2],  Integer.parseInt(persons[3]));
                personsArrayList.add(person);
            }
            System.out.println("Import: Done");
//            }
//            else 
//                System.err.println("This path isn't file!");
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e){
            e.printStackTrace();
        }
        finally {
            if(br != null){
                try {
                    br.close();
                } 
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    public ArrayList<Person> sortInformationByAscendingOrder() {
        Collections.sort(personsArrayList, (c1, c2) -> {
            return c1.getCode().compareTo(c2.getCode());
        });
        return personsArrayList;
    }
    
    public void updatePersonInfo(String code){
        for (Person p : personsArrayList) {
            if(p.getCode().equals(code)){
                System.out.println("Enter new name: ");
                p.setName(Validation.checkInputString());
                System.out.println("Enter new address: ");
                p.setAddress(Validation.checkInputString());
                System.out.println("Enter new salary: ");
                p.setSalary(Validation.checkInputSalary());
            }
        }
    }
    
    public void exportFileCSV(){
        String path = Validation.checkInputString();
        FileWriter fw = null;
        try {
            fw = new FileWriter(path);
            // FileWriter(File file)
            for (Person p : personsArrayList) {
                fw.append(String.valueOf(p.getCode()));
                fw.append(",");
                fw.append(String.valueOf(p.getName()));
                fw.append(",");
                fw.append(String.valueOf(p.getAddress()));
                fw.append(",");
                fw.append(String.valueOf(p.getSalary()));
                fw.append(",");
                fw.append("\n");
            }
            System.out.println("Export: Done");                
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }         
        finally {
            try {
                fw.flush();
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
