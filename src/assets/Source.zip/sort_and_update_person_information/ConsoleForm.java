/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sort_and_update_person_information;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    ManagePerson managePerson = new ManagePerson();
    
    private List<String> choices = Arrays.asList("====== Sort & Update Person Information ======",
                                                "1. Import Person Information",
                                                "2. Sort",
                                                "3. Update",
                                                "4. Export CSV",
                                                "5. Exit",
                                                "===============================",
                                                "Please choice one option: ");
    
    public int getChoice() {
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 5);
    }
    
    public void importPersonInfor(){
        System.out.println("------ Import CSV ------");
        System.out.println("Enter path: ");
        managePerson.importPersonInfor();
    }
    
    public void sortPerson(){
        System.out.println("------ Sort ------");
        if(!managePerson.getPersonsArrayList().isEmpty()){
            managePerson.sortInformationByAscendingOrder();
            System.out.println("Sort: Done");
        }
        else
            System.err.println("No data to sort!\n");
    }
    
    public void updatePerson(){
        System.out.println("------ Update ------");
        if(!managePerson.getPersonsArrayList().isEmpty()){
            System.out.println("Enter code: ");
            managePerson.updatePersonInfo(Validation.checkIdExist(managePerson.getPersonsArrayList()));
            System.out.println("Update: Done");
        }
        else
            System.err.println("No data to update!\n");
    }
    
    public void exportFileCSV(){
        System.out.println("------ Export CSV ------");
        System.out.println("Enter path: ");
        managePerson.exportFileCSV();
    }
    
    public void execute(){
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    importPersonInfor();
                    break;
                case 2:
                    sortPerson();
                    break;
                case 3:
                    updatePerson();
                    break;
                case 4: 
                    exportFileCSV();
                    break;
                case 5: 
                    System.exit(0); 
            }
        }
    }
    
}
