/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package handle_file_program;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    private List<String> choices = Arrays.asList("=========== File Processing ===========",
                                                 "1. Check Path",
                                                 "2. Get file name with type java",
                                                 "3. Get file with size greater than input",
                                                 "4. Write more content to file",
                                                 "5. Read file and count characters",
                                                 "6. Exit",
                                                 "============================",
                                                 "Please choice one option: ");
    
    public int getChoice() {
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 6);
    }
    
    public void checkPath(){
        System.out.println("---------- Check Path ----------");
        System.out.println("Enter Path: ");
        String path = Validation.checkInputString();
        File file = new File(path);
        if(file.exists() && file.isFile())
            System.out.println("Path to File");
        else if(file.exists() && file.isDirectory())
            System.out.println("Path to Directory");
        else 
            System.out.println("Path doesn't exist");
    }
    
    public void getFileNameWithTypeJava(){
        System.out.println("---------- Get file name with type Java ----------");
        ArrayList<String> fileName = new ArrayList<>();
        System.out.println("Enter Path: ");
        String path = Validation.checkInputString();
        File file = new File(path);
        if(file.exists() && file.isDirectory()){
            File[] fileList = file.listFiles();
            for(int i = 0; i < fileList.length; i++){
                if(fileList[i].isFile() && fileList[i].getName().endsWith(".java"))
                    fileName.add(fileList[i].getName());
            }
        }
        else{
            System.out.println("Path doesn't exist");
            return;
        }
        System.out.println("Result " + fileName.size() + " file!");
        for (int i = 0; i < fileName.size(); i++) 
            System.out.println(fileName.get(i));  
    }
    
    public void getFileWithSizeGreaterThanInput(){
        System.out.println("---------- Get file with size greater than input ----------");
        System.out.println("Enter size (Integer): ");
        int size = Validation.checkInputSize();
        System.out.println("Enter Path: ");
        String path = Validation.checkInputString();
        File file = new File(path);
        if(file.exists() && file.isDirectory()){
            File[] fileList = file.listFiles();
            for(int i = 0; i < fileList.length; i++){
                if(fileList[i].isFile() && fileList[i].length() > size)
                    System.out.println(fileList[i].getName());
            }
        }
        else{
            System.out.println("Path doesn't exist");
            return;
        }
    }
    
    public void writeMoreContentToFile() throws IOException{
        System.out.println("---------- Write more content to file -----------");
        System.out.println("Enter Content: ");
        String content = Validation.checkInputString();
        System.out.println("Enter Path: ");
        String path = Validation.checkInputString();
        File file = new File(path);
        if(file.exists() && file.isFile()){
            FileWriter fileWriter = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fileWriter);
            writer.append(content);
            writer.close();
            System.out.println("Write done");
        }
        else
            System.out.println("Path doesn't exist");
    }
    
    public void readFileAndCountCharacters() throws FileNotFoundException, IOException{
        System.out.println("---------- Read file and count characters ----------");
        System.out.println("Enter Path: ");
        String path = Validation.checkInputString();
        File file = new File(path);
        if(file.exists() && file.isFile()){
            FileReader fileReader = new FileReader(file);
            BufferedReader reader = new BufferedReader(fileReader);
            String line = reader.readLine();
            int count = 0;
            while(line != null){
                String [] parts = line.split(" ");
                for (String s : parts)
                    count++;
                line = reader.readLine();
            }
            System.out.println("Total: " + count);
        }
        else
            System.out.println("Path doesn't exist");  
    }
    
    public void execute() throws IOException{
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    checkPath();
                    break;
                case 2:
                    getFileNameWithTypeJava();
                    break;
                case 3:
                    getFileWithSizeGreaterThanInput();
                    break; 
                case 4:
                    writeMoreContentToFile();
                    break;
                case 5:
                    readFileAndCountCharacters();
                    break;    
                case 6: 
                    System.exit(0); 
            }
        }    
    }
    
    
}
