/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QLNV;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author MSI GL63
 */
public class ManageEmployee {
    
    private ArrayList<Employee> employee = new ArrayList<>();

    public ManageEmployee() {}
    
    public ManageEmployee(ArrayList<Employee> employee){
        this.employee = employee;
    }

    public ArrayList<Employee> getEmployee() {
        return employee;
    }

    public void setEmployee(ArrayList<Employee> employee) {
        this.employee = employee;
    }
    
    public void addInforEmployee(Employee e){
        employee.add(e);
    }
    
    public ArrayList<Employee> sortInformationByAscendingOrder(ArrayList<Employee> result ) {
        Collections.sort(result, new Comparator<Employee>() {
            @Override
            public int compare(Employee c1, Employee c2) {
                return c2.getBirthDay().compareTo(c1.getBirthDay());
            }
        });
        return result;
    }
      
}
