/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QLNV;

/**
 *
 * @author MSI GL63
 */
public class Fresher extends Employee{
    private String graduation_Date;
    private String graduation_Rank;
    private String education;

    public Fresher() {
        super();
    }

    public Fresher(String graduation_Date, String graduation_Rank, String education, String id, String fullName, int birthDay, String phone, String email, int employee_Type) {
        super(id, fullName, birthDay, phone, email, employee_Type);
        this.graduation_Date = graduation_Date;
        this.graduation_Rank = graduation_Rank;
        this.education = education;
    }
    
    public String getGraduation_Date() {
        return graduation_Date;
    }

    public void setGraduation_Date(String graduationDate) {
        this.graduation_Date = graduationDate;
    }

    public String getGraduation_Rank() {
        return graduation_Rank;
    }

    public void setGraduation_Rank(String graduationRank) {
        this.graduation_Rank = graduationRank;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }
}
