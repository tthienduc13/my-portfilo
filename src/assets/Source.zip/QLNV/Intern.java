/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QLNV;

/**
 *
 * @author MSI GL63
 */
public class Intern extends Employee{
    
    private String majors;
    private String semester;
    private String university_Name;

    public Intern() {
        super();
    }

    public Intern(String majors, String semester, String university_Name, String id, String fullName, int birthDay, String phone, String email, int employee_Type) {
        super(id, fullName, birthDay, phone, email, employee_Type);
        this.majors = majors;
        this.semester = semester;
        this.university_Name = university_Name;
    }

    public String getMajors() {
        return majors;
    }

    public void setMajors(String majors) {
        this.majors = majors;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getUniversity_Name() {
        return university_Name;
    }

    public void setUniversity_Name(String universityName) {
        this.university_Name = universityName;
    }
    
}
