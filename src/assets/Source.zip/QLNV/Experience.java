/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QLNV;

/**
 *
 * @author MSI GL63
 */
public class Experience extends Employee{
    
    private int expInYear;
    private String proSkill;

    public Experience() {
        super();
    }

    public Experience(int expInYear, String proSkill, String id, String fullName, int birthDay, String phone, String email, int employee_Type) {
        super(id, fullName, birthDay, phone, email, employee_Type);
        this.expInYear = expInYear;
        this.proSkill = proSkill;
    }

    public int getExpInYear() {
        return expInYear;
    }

    public void setExpInYear(int expInYear) {
        this.expInYear = expInYear;
    }

    public String getProSkill() {
        return proSkill;
    }

    public void setProSkill(String proSkill) {
        this.proSkill = proSkill;
    }
    
}
