/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QLNV;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    ManageEmployee manageEmployee = new ManageEmployee();
    
    private List<String> choices = Arrays.asList("CANDIDATE MANAGEMENT SYSTEM",
                                                 "1. Experience",
                                                 "2. Fresher",
                                                 "3. Internship",
                                                 "4. Show Information",
                                                 "5. Exit",
                                                 "============================",
                                                 "Enter your choice: ");
    
    public int getChoice() {
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 5);
    }
    
    public void createExperience(){
        while (true) {           
            System.out.println("========== EXPERIENCE CANDIDATE ===========");
            Experience employee = new Experience();
            System.out.println("Enter candidate id: ");
            employee.setID(Validation.checkInputString());
            System.out.println("Enter full name: ");
            employee.setFullName(Validation.checkInputString());
            System.out.println("Enter birth date: ");
            employee.setBirthDay(Validation.checkInputBirthDate());
            System.out.println("Enter phone: ");
            employee.setPhone(Validation.checkInputPhone());
            System.out.println("Enter email: ");
            employee.setEmail(Validation.checkInputEmail());
            employee.setEmployee_type(0);
            System.out.println("Enter year of experience: ");
            employee.setExpInYear(Validation.checkInputYearExperience());
            System.out.println("Enter professional skill: ");
            employee.setProSkill(Validation.checkInputString());
            manageEmployee.addInforEmployee(employee);
            System.err.println("Successful!");
            if(Validation.checkInputYN() == false)
                break;
       }
    }
   
    public void createFresher(){
        while (true) {        
            System.out.println("========== FRESHER CANDIDATE ==============");
            Fresher employee = new Fresher();
            System.out.println("Enter candidate id: ");
            employee.setID(Validation.checkInputString());
            System.out.println("Enter full name: ");
            employee.setFullName(Validation.checkInputString());
            System.out.println("Enter birth date: ");
            employee.setBirthDay(Validation.checkInputBirthDate());
            System.out.println("Enter phone: ");
            employee.setPhone(Validation.checkInputPhone());
            System.out.println("Enter email: ");
            employee.setEmail(Validation.checkInputEmail());
            employee.setEmployee_type(1);
            System.out.println("Enter graduated time: ");
            employee.setGraduation_Date(Validation.checkInputString());
            System.out.println("Enter rank of graduation: ");
            employee.setGraduation_Rank(Validation.checkInputGraduationRank());
            System.out.println("Enter university where student graduated: ");
            employee.setEducation(Validation.checkInputString());
            manageEmployee.addInforEmployee(employee);
            System.err.println("Successful!");
            if(Validation.checkInputYN() == false)
                break;
       }
    }
    
    
    public void createInternship(){
        while (true) {     
            System.out.println("=========== INTERN CANDIDATE ==============");
            Intern employee = new Intern();
            System.out.println("Enter candidate id: ");
            employee.setID(Validation.checkInputString());
            System.out.println("Enter full name: ");
            employee.setFullName(Validation.checkInputString());;
            System.out.println("Enter birth date: ");
            employee.setBirthDay(Validation.checkInputBirthDate());
            System.out.println("Enter phone: ");
            employee.setPhone(Validation.checkInputPhone());
            System.out.println("Enter email: ");
            employee.setEmail(Validation.checkInputEmail());
            employee.setEmployee_type(2);
            System.out.println("Enter major: ");
            employee.setMajors(Validation.checkInputString());
            System.out.println("Enter semester: ");
            employee.setSemester(Validation.checkInputString());
            System.out.println("Enter university name: ");
            employee.setUniversity_Name(Validation.checkInputString());
            manageEmployee.addInforEmployee(employee);
            System.err.println("Successful!");
            if(Validation.checkInputYN() == false)
                break;
        }
    }
    
    public void printEmploy(){
        manageEmployee.sortInformationByAscendingOrder(manageEmployee.getEmployee());
        System.out.println("========== EXPERIENCE CANDIDATE ===========");
        for (Employee e : manageEmployee.getEmployee()) {
            if(e instanceof Experience)
                System.out.printf("%-5s%-15s%-5d%-15s%-10s%-10s%-10s", e.getID(),e.getFullName(),e.getBirthDay(),e.getPhone(),e.getEmail(),((Experience) e).getExpInYear(),((Experience) e).getProSkill());
        }
        System.out.println("========== FRESHER CANDIDATE ==============");
        for (Employee e : manageEmployee.getEmployee()) {
            if(e instanceof Fresher)
                System.out.printf("%-5s%-15s%-5d%-15s%-10s%-10s%-10s%-10s", e.getID(),e.getFullName(),e.getBirthDay(),e.getPhone(),e.getEmail(),((Fresher) e).getGraduation_Date(),((Fresher) e).getGraduation_Rank(),((Fresher) e).getEducation());
        }
        System.out.println("=========== INTERN CANDIDATE ==============");
        for (Employee e : manageEmployee.getEmployee()) {
            if(e instanceof Intern)
                System.out.printf("%-5s%-15s%-5d%-15s%-10s%-10s%-10s%-10s", e.getID(),e.getFullName(),e.getBirthDay(),e.getPhone(),e.getEmail(),((Intern) e).getMajors(),((Intern) e).getSemester(),((Intern) e).getUniversity_Name());
        }
    } 
    
    public void execute(){
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    createExperience();
                    break;
                case 2:
                    createFresher();
                    break;
                case 3:
                    createInternship();
                    break; 
                case 4:
                    printEmploy();
                    break;
                case 5: 
                    System.exit(0); 
            }
        }    
    }
}

