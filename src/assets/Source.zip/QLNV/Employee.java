/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QLNV;

/**
 *
 * @author MSI GL63
 */
public class Employee {
    
    private String id;
    private String fullName; 
    private int birthDay;
    private String phone;
    private String email; 
    private int employee_Type;

    public Employee() {}

    public Employee(String id, String fullName, int birthDay, String phone, String email, int employee_Type) {
        this.id = id;
        this.fullName = fullName;
        this.birthDay = birthDay;
        this.phone = phone;
        this.email = email;
        this.employee_Type = employee_Type;
    }
    
    
    public String getID() {
        return id;
    }

    public void setID(String ID) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String FullName) {
        this.fullName = fullName;
    }

    public int getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(int BirthDay) {
        this.birthDay = BirthDay;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String Phone) {
        this.phone = Phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String Email) {
        this.email = Email;
    }

    public int getEmployee_type() {
        return employee_Type;
    }

    public void setEmployee_type(int Employee_type) {
        this.employee_Type = Employee_type;
    }
    
    
}
