/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package create_a_java_console_program_to_manage_items_in_a_grocery_store;

/**
 *
 * @author MSI GL63
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ConsoleForm consoleForm = new ConsoleForm();
        consoleForm.execute();
    }
    
}
