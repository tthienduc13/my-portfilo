/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_java_console_program_to_manage_items_in_a_grocery_store;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    ManageItem manageItem = new ManageItem();
    
    private List<String> choices = Arrays.asList("======== Items Management =========",
                                                "1. Create Item",
                                                "2. View item information",
                                                "3. Search",
                                                "4. Exit",
                                                "===============================",
                                                "Enter your choice: ");
    
    public int getChoice() {
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 4);
    }
    
    public void createItem(){
        Item item = new Item();
        System.out.println("--------- Create Item ---------");
        System.out.println("Enter Code: ");
        item.setCode(Validation.checkIdExist(manageItem.getItemArrayList()));
        System.out.println("Enter Name: ");
        item.setName(Validation.checkInputString());
        System.out.println("Enter Price: ");
        item.setPrice(Validation.checkInputInteger());
        manageItem.addInforItem(item);
        System.err.println("Create successful!");
    }
    
    public void viewItemInformation(){
        System.out.println("--------------------Items Information-----------------------");
        if(manageItem.getItemArrayList().isEmpty())
            System.err.println("No iteam to view!");
        else{
            System.out.printf("%-10s%-15s%-15s\n", "Code", "Name", "Price");
            for (Item i : manageItem.getItemArrayList()) {
                System.out.printf("%-10s%-15s%-15d\n", i.getCode(), i.getName(), i.getPrice());
            }
        }
    }
    
    public void searchItem(){
        System.out.println("------- Search --------");
        if(manageItem.getItemArrayList().isEmpty())
            System.err.println("No iteam to search!");
        else{
            System.out.println("Enter Code: ");
            for(Item i : manageItem.search(Validation.checkInputString())){
                System.out.printf("%-10s|%-15s|%-15d\n", i.getCode(), i.getName(), i.getPrice());
            }   
        }
    }
    
    public void execute() {
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    createItem();
                    break;
                case 2:
                    viewItemInformation();
                    break;
                case 3: 
                    searchItem();
                    break;
                case 4: 
                    System.exit(0); 
            }
        }
    }
}
