/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_java_console_program_to_manage_items_in_a_grocery_store;

import java.util.ArrayList;

/**
 *
 * @author MSI GL63
 */
public class ManageItem {
    
    private ArrayList<Item> itemArrayList = new ArrayList<>();

    public ManageItem() {}
    
    public ManageItem(ArrayList <Item> itemArrayList){
        this.itemArrayList = itemArrayList;
    }

    public ArrayList<Item> getItemArrayList() {
        return itemArrayList;
    }
    
    public void setItemArrayList(ArrayList<Item> itemArrayList) {
        this.itemArrayList = itemArrayList;
    }
    
    public void addInforItem(Item item){
        itemArrayList.add(item);
    }
    
    public ArrayList<Item> search(String code){
        ArrayList<Item> temp = new ArrayList<>();
        for (Item i : itemArrayList) {
            if (i.getCode().equals(code)) {
                temp.add(i);
                return temp;
            }
        }
        System.err.println("Item does not exist!");
        return temp;
    }
    
}
