/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package develop_the_contact_management_program;

import java.util.ArrayList;

/**
 *
 * @author MSI GL63
 */
public class ManageContact {
    private ArrayList<Contact> contactArrayList = new ArrayList<>();
    
    public ManageContact(){}
    
    public ManageContact(ArrayList<Contact> contactArrayList){
        this.contactArrayList = contactArrayList;
    }
    
    public ArrayList<Contact> getContactArrayList(){
        return contactArrayList;
    }

    public void setContactArrayList(ArrayList<Contact> contactArrayList){
        this.contactArrayList = contactArrayList;
    }
    
    public void addContactInformation (Contact c){
        contactArrayList.add(c);
    }
    
    public Contact getRecentlyEnteredInformation(){
        if(contactArrayList.size() > 0){
            return contactArrayList.get(contactArrayList.size() - 1);
        }
        return null;
    }
    
    public ArrayList<Contact> printContact(){
        ArrayList<Contact> result = new ArrayList<>();
        for (Contact c : contactArrayList){
            System.out.printf("%-5d%-20s%-20s%-20s%-20s%-20s%-20s\n", c.getContactID(), c.getFullName(), c.getFirstName(), c.getLastName(), c.getGroup(), c.getAddress(), c.getPhone());
        }
        return result;
    }
    
    public ArrayList<Contact> getContactByID(int idDelete){
        ArrayList<Contact> result = new ArrayList<>();
        for (Contact c : contactArrayList)
            if (c.getContactID() == idDelete);
                return result;
    }
    
    public ArrayList<Contact> deleteContact(int idDelete){
        ArrayList<Contact> contactDelete = getContactByID(idDelete);
        if(contactDelete == null){
            System.err.println("Not found contact!");
            return contactDelete;
        }
        else
            contactDelete.remove(idDelete);
        return null;       
    }
}   
