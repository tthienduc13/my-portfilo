/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package develop_the_contact_management_program;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Scanner;


/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    ManageContact manageContact = new ManageContact();
    private List<String> choices = Arrays.asList("========= Contact program =========",
                                                 "1. Add a Contact",
                                                 "2. Display all Contact",
                                                 "3. Delete a Contact",
                                                 "4. Exit",
                                                 "Enter your choice: ");
    
    public int getChoice() {
        Scanner sc = new Scanner(System.in);
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 4);
    }
    
    public void inputInformation(){
        Scanner sc = new Scanner(System.in);
        Contact contact = new Contact();
        System.out.println("-------- Add a Contact --------");
        System.out.println("Enter First Name: ");
        contact.setFirstName(Validation.checkInputString());
        System.out.println("Enter Last Name: ");
        contact.setLastName(Validation.checkInputString());
        System.out.println("Enter Group: ");
        contact.setGroup(Validation.checkInputString());
        System.out.println("Enter Address: ");
        contact.setAddress(Validation.checkInputString());
        System.out.println("Enter Phone: ");
        contact.setPhone(Validation.checkInputPhone());
        manageContact.addContactInformation(contact);
        System.err.println("Successful!");           
    }
    
    public void displayAll(){
        System.out.println("--------------------------------- Display all Contact ----------------------------");
        System.out.printf("%-5s%-20s%-20s%-20s%-20s%-20s%-20s\n", "Id", "Name", "First name", "Last name", "Group", "Address", "Phone");
        ArrayList<Contact> temp = manageContact.printContact();
    }   
    
    public void displayDelete(){
        System.out.println("------- Delete a Contact -------");
        System.out.println("Enter ID: ");
        int contactID = Validation.checkInputInteger();
        ArrayList<Contact> result = manageContact.deleteContact(contactID);
        if(result.isEmpty())
            System.err.println("Not found contact!");
        else
            System.out.println("Successful!");
    }
    
    public void execute() {
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    inputInformation();
                    break;
                case 2:
                    displayAll();
                    break;
                case 3:
                    displayDelete();
                    break;
                case 4: 
                    System.exit(0); 
            }
        }
     }
}
        