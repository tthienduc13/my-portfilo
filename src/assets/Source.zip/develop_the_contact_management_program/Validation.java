/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package develop_the_contact_management_program;

import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class Validation {
    
    private static final String VALID_PHONE = "[(]?[0-9]{3}[)]?[-. ]?[0-9]{3}[-. ]?[0-9]{4}"
    +                                         "|[0-9]{3}[-][0-9]{3}[-][0-9]{4}[ a-z0-9]+";

    public static int checkInputInteger(){
        Scanner sc = new Scanner (System.in);
        while(true){            
            try{
                Integer input = null;
                String intInput = sc.nextLine();
                input = new Integer(intInput);
                if(input > 0)
                    return input;
                else
                    System.err.println("Please input a positive integer number!");
                    System.out.println("Please enter again: ");
            } 
            catch(NumberFormatException e){
                System.err.println("Please input a integer number!");
                System.out.println("Please enter again: "); 
            }
        }       
    }
    
    public static int checkInputIntLimit(int min, int max) {
        while(true){
            try{
                int input = checkInputInteger();
                if (input < min || input > max)
                    throw new NumberFormatException();
                return input;
            } 
            catch(NumberFormatException e){
                System.err.println("Please input number in rage [" + min + ", " + max + "]!");
                System.out.print("Please enter again: ");
            }
        }
    }
    
    public static String checkInputString(){
        Scanner sc = new Scanner(System.in);
        while(true){
            String input = sc.nextLine();
            if(input.isEmpty()){
                System.err.println("Please input a string!");
                System.out.println("Please enter again: ");
            }
            else
                return input;
        }
    }
    
    public static boolean checkInputYN(){
        while (true) {
            String inputString = checkInputString();
            if (inputString.equalsIgnoreCase("Y")) 
                return true;
            else if (inputString.equalsIgnoreCase("N")) 
                return false;
            else{
                System.err.println("Please input Y/y or N/n!");
                System.out.print("Please enter again: ");
            }
        }
    }
    
    public static String checkInputPhone(){
        while(true){
            String input = checkInputString();
            if(input.matches(VALID_PHONE))
                return input;
            else{
                System.err.println("");
                        System.out.print("Please enter again: ");
        
            }
        }    
    }
}
