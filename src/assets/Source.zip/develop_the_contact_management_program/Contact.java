/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package develop_the_contact_management_program;

/**
 *
 * @author MSI GL63
 */

public class Contact {
    private int contactID;
    private String fullName;
    private String group;
    private String address;
    private String phone;
    private String lastName;
    private String firstName;
    
    public Contact(){}

    public Contact(int contactID, String fullName, String group, String address, String phone, String lastName, String firstName) {
        this.contactID = contactID;
        this.fullName = fullName;
        this.group = group;
        this.address = address;
        this.phone = phone;
        this.lastName = lastName;
        this.firstName = firstName;
    }

    public int getContactID() {
        return contactID;
    }

    public String getFullName() {
        return fullName = firstName + " " + lastName;
    }

    public String getGroup() {
        return group;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setContactID(int contactID) {
        this.contactID = contactID;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName = firstName + " " + fullName;
    }
   
    public void setGroup(String group) {
        this.group = group;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
}
