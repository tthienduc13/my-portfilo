/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package letter_and_character_count;

import java.util.Scanner;
import java.util.HashMap;
import java.util.StringTokenizer;

public class LetterAndCharacterCount {
    
    HashMap<Character, Integer> charCounter = new HashMap<Character, Integer>();
    HashMap<String, Integer> wordCounter = new HashMap<String, Integer>();
    
    public static String inputContent(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your content: ");
        String content = sc.nextLine();
        return content;
    }
    public void countContent(String content){
        for(char ch : content.toCharArray()){
            if(Character.isSpaceChar(ch)) 
               continue;
            if(!charCounter.containsKey(ch))
                charCounter.put(ch, 1);
            else
                charCounter.put(ch, ( charCounter.get(ch)) + 1);
        }
        StringTokenizer tokenizer = new StringTokenizer(content);
        while(tokenizer.hasMoreTokens()){
            String token = tokenizer.nextToken();
            if(!wordCounter.containsKey(token)) 
                wordCounter.put(token, 1);
            else
                wordCounter.put(token, (wordCounter.get(token)) + 1);
        }
    }
    public void outputResult(){
        System.out.println(wordCounter);
        System.out.println(charCounter);
    }
    
    public static void main(String[] args) {
        LetterAndCharacterCount counter = new LetterAndCharacterCount();
        counter.countContent(counter.inputContent());
        counter.outputResult();
    }
    
    
}

