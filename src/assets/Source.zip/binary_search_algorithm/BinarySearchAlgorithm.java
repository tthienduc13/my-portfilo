/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package binary_search_algorithm;

import java.util.Scanner;
import java.util.Random;

public class BinarySearchAlgorithm {  
    static int getSize(){
        System.out.println("Enter number of array: ");
        int size = checkValueOfSize();
        return size;
    }
    static int checkValueOfSize(){
        Scanner sc = new Scanner (System.in);
        while(true){            
            try{
                Integer size = null;
                String intSize = sc.nextLine();
                size = new Integer(intSize);
                if(size>0)
                    return size;
                else
                    System.out.println("Please input positive number!");
            } 
            catch(NumberFormatException e){
                System.err.println("Please input number!");
                System.out.println("Please enter again: "); 
            }
        }       
    }
    static int [] randomValue(int a[]){
        Random rd = new Random();
        for(int i = 0; i < a.length; i++)
            a[i]=rd.nextInt(20);
        return a;
    }
    static int searchValue(){
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter search value: "); 
        int searchValue = sc.nextInt();
        return searchValue;
    }
    static int [] sortByBubbleSort(int a[]){
        for(int i = 0; i < a.length - 1; i++) {
            boolean swap = false;
            for(int j = 0; j < a.length - 1 - i; j++){  
                if(a[j] > a[j+1]){
                int temp = a[j];
                    a[j] = a[j+1];
                    a[j+1] = temp;
                    swap = true;    
                if(swap == false)
                    break;
                }   
            }
        }
        return a;
    }
    static void outputAfterSort(int a[]){
        System.out.print("Sorted array: ");
        System.out.print("[");
        for(int i = 0; i < a.length; i++){
            System.out.print(a[i]);
            if(i < a.length - 1)
                System.out.print(", ");
        }
        System.out.print("]");
    }
    static int searchByBinarySearch(int a[], int searchValue, int left, int right){
        if(left > right)
            return -1;
        int middle = (left + right) / 2;
        if(a[middle] == searchValue)
            return middle;
        else if(a[middle] > searchValue)
            return searchByBinarySearch(a, searchValue, left, middle - 1);
        else
            return searchByBinarySearch(a, searchValue, middle + 1, right);
    }
    static void printIndex(int searchValue, int foundIndex){
        if(foundIndex == -1)
            System.out.println("\nSearch value " + searchValue + " not found! ");   
        else
            System.out.println("\nFound " + searchValue + " at index: " + foundIndex);
    }
    
    public static void main(String[] args) {
        int size = getSize();
        int searchValue = searchValue();
        int a[] = new int[size];
        randomValue(a);
        sortByBubbleSort(a);
        outputAfterSort(a);
        printIndex(searchValue, searchByBinarySearch(a, searchValue, 0, size - 1));
    }    
}
