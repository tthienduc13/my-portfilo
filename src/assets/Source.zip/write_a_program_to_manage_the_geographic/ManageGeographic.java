/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package write_a_program_to_manage_the_geographic;

/**
 *
 * @author MSI GL63
 */
public class ManageGeographic {

    public static void main(String[] args) {
        ConsoleForm consoleForm = new ConsoleForm();
        consoleForm.execute();
    }
    
}
