/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package write_a_program_to_manage_the_geographic;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    ManageEastAsiaCountries manageEastAsiaCountries = new ManageEastAsiaCountries();
    private List<String> choices = Arrays.asList("\t\t\t\tMENU",
                                                "==========================================================================",
                                                "1. Input the information of countries in East Asia",
                                                "2. Display the information of country you've just input",
                                                "3. Search the information of country by user-entered name",
                                                "4. Display the information of countries sorted name in ascending order",
                                                "5. Exit",
                                                "==========================================================================",
                                                "Enter your choice: ");
    public int getChoice() {
        Scanner sc = new Scanner(System.in);
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 5);
    }
    
    public void inputInformation() {
        while (true){ 
            EastAsiaCountries eastAsiaCountries = new EastAsiaCountries();
            System.out.println("Enter code of country: ");
            eastAsiaCountries.setCountryCode(Validation.checkInputString());
            System.out.println("Enter name of country: ");
            eastAsiaCountries.setCountryName(Validation.checkInputString());
            System.out.println("Enter total Area: ");
            eastAsiaCountries.setTotalArea(Validation.checkInputFloat());
            System.out.println("Enter terrain of country: ");
            eastAsiaCountries.setCountryTerrain(Validation.checkInputString());
            manageEastAsiaCountries.addCountryInformation(eastAsiaCountries);
            System.err.println("Add successful!");
            if(Validation.inputYN() == false)
                break;
        }
    }
    
    public void displayAll() {
        ArrayList<EastAsiaCountries> temp = manageEastAsiaCountries.sortInformationByAscendingOrder();
        System.out.printf("%-20s%-20s%-20s%-20s\n", "ID", "Name", "Total Area", "Terrain");
        for (EastAsiaCountries e: temp)
            System.out.printf("%-20s%-20s%-20.1f%-20s\n", e.getCountryCode(), e.getCountryName(), e.getTotalArea(), e.getCountryTerrain());
    }   
    
    public void displayInput(){
        EastAsiaCountries temp = manageEastAsiaCountries.getRecentlyEnteredInformation();
        System.out.printf("%-20s%-20s%-20s%-20s\n", "ID", "Name", "Total Area", "Terrain");
        System.out.printf("%-20s%-20s%-20.1f%-20s\n", temp.getCountryCode(), temp.getCountryName(), temp.getTotalArea(), temp.getCountryTerrain());
    }
    
    public void displaySearch() {
        System.out.println("Enter the name you want to search for: ");
        String name = Validation.checkInputString();
        ArrayList<EastAsiaCountries> result = manageEastAsiaCountries.searchInformationByName(name);
        if (!result.isEmpty()) {
            System.out.printf("%-20s%-20s%-20s%-20s\n", "ID", "Name", "Total Area", "Terrain");
            for (EastAsiaCountries e : result) {
                System.out.printf("%-20s%-20s%-20.1f%-20s\n", e.getCountryCode(), e.getCountryName(), e.getTotalArea(), e.getCountryTerrain());
            }
        } else {
            System.err.println("Not found!");
        }
    }
    
    public void execute() {
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    inputInformation();
                    break;
                case 2:
                    displayInput();
                    break;
                case 3:
                    displaySearch();
                    break;
                case 4: 
                    displayAll();
                    break;
                case 5: 
                    System.exit(0); 
            }
        }
    }
    
}
