/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program_to_manage_worker_information;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class Validation {
    
    public static final String NAME_VALID = "[A-Za-z]+"; 
    
    static Scanner sc = new Scanner(System.in);
    
    public static String checkInputString(){
        while(true){
            String input = sc.nextLine();
            if(input.isEmpty()){
                System.err.println("Please input a string!");
                System.out.println("Please enter again: ");
            }
            else
                return input;
        }
    }
    
    public static String checkInputName(){
        Scanner sc = new Scanner(System.in);
        while(true){
            String input = sc.nextLine();
            if(input.isEmpty()){
                System.err.println("Please input a string!");
                System.out.println("Please enter again: ");
            }
            if(input.matches(NAME_VALID))
                return input;
            else{
                System.err.println("Please don't input a number or special character!");
                System.out.print("Please enter again: ");
            }   
        }
    }
    
    public static int checkInputInteger(){
        while(true){            
            try{
                Integer input = null;
                String intInput = sc.nextLine();
                input = new Integer(intInput);
                if(input > 0)
                    return input;
                else
                    System.err.println("Please input a positive integer number!");
                    System.out.println("Please enter again: ");
            } 
            catch(NumberFormatException e){
                System.err.println("Please input a integer number!");
                System.out.println("Please enter again: "); 
            }
        }       
    }
    
    public static double checkInputSalary(){
        while (true){            
            String stringInputSalary = checkInputString();
            if(stringInputSalary.isEmpty()){
                System.err.println("You must input Salary!");
                System.out.println("Please enter again: ");
            }
            try{
                double input = Double.parseDouble(stringInputSalary);
                if(input > 0)
                    return input;
                else{
                    System.err.println("Salary is greater than zero!");
                    System.out.println("Please enter again: ");
                }
            } 
            catch(NumberFormatException e){
                System.err.println("You must input digidt!");
                System.out.println("Please enter again: ");
            }
        }    
    }
    
    public static int checkInputIntLimit(int min, int max) {
        while(true){
            try{
                int input = checkInputInteger();
                if (input < min || input > max)
                    throw new NumberFormatException();
                return input;
            } 
            catch(NumberFormatException e){
                System.err.println("Please input number in rage [" + min + ", " + max + "]!");
                System.out.print("Please enter again: ");
            }
        }
    }
    
    public static boolean inputYN(){
        System.out.println("Do you want to continue?");
        while (true) {
            String inputString = checkInputString();
            if (inputString.equalsIgnoreCase("Y")) 
                return true;
            else if (inputString.equalsIgnoreCase("N")) 
                return false;
            else{ 
                System.err.println("Please input Y/y or N/n");
                System.out.print("Please enter again: ");
            }
        }
    }
    
}

