/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program_to_manage_worker_information;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    Manage manage = new Manage();
    SalaryHistory salaryHistory = new SalaryHistory();
    
    private List<String> choices = Arrays.asList("======== Worker Management =========",
                                                "1. Add Worker",
                                                "2. Up salary",
                                                "3. Down salary",
                                                "4. Display Information salary",
                                                "5. Exit",
                                                "======================================",
                                                "Enter your choice: ");
    
    public int getChoice() {
        Scanner sc = new Scanner(System.in);
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 5);
    }
    
    public void inputWorker(){
        while (true){
            Worker worker = new Worker();
            System.out.println("--------- Add Worker ----------");
            System.out.println("Enter Code: ");
            worker.setID(Validation.checkInputString());
            System.out.println("Enter Name: ");
            worker.setName(Validation.checkInputName());
            System.out.println("Enter Age: ");
            worker.setAge(Validation.checkInputIntLimit(18,50));
            System.out.println("Enter salary: ");
            worker.setSalary(Validation.checkInputSalary());
            System.out.println("Enter work location: ");
            worker.setWorkLocation(Validation.checkInputString());
            manage.addWorker(worker);
            salaryHistory.addWorkerInHistory(worker);
            System.err.println("Successful!");
            if(Validation.inputYN() == false)
                break;
        }
    }
    
    public void execute() {
        while (true) {
            int choice = getChoice();
            switch (choice) {
                case 1:
                    inputWorker();
                    break;
                case 2:
                    salaryHistory.UpSalary();
                    break;
                case 3:
                    salaryHistory.DownSalary();
                    break;
                case 4:
                    salaryHistory.OutputHistorySalary();
                    break;
                case 5:
                    System.exit(0);
            }
        }
    }
   
}
