/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program_to_manage_worker_information;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class Manage{
    
    private ArrayList<Worker> workers = new ArrayList<>();
    private ArrayList<SalaryHistory> salaryHistorys = new ArrayList<>();

    public Manage() {
    }
    
    public Manage(ArrayList<Worker> workers, ArrayList<SalaryHistory> salaryHistorys){
        this.workers = this.workers;
        this.salaryHistorys = this.salaryHistorys;
    }
    
    public ArrayList<Worker> getWorkers(){
        return workers;
    }
    
    public void setWorkers(ArrayList<Worker> workers) {
        this.workers = workers;
    }
    
    public ArrayList<SalaryHistory> getSalaryHistorys(){
        return salaryHistorys;
    }

    public void setSalaryHistorys(ArrayList<SalaryHistory> salaryHistorys) {
        this.salaryHistorys = salaryHistorys;
    }

    public void addWorker(Worker worker){
        workers.add(worker);
    }
    
}
