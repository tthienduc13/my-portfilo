/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program_to_manage_worker_information;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class SalaryHistory{
    
    ArrayList<Worker> workerArrayList = new ArrayList<>();
    Worker worker = new Worker();
    
    public void addWorkerInHistory(Worker worker){
        workerArrayList.add(worker);
    }
    
    ArrayList<Worker> Up = new ArrayList<>();
    ArrayList<Worker> Down = new ArrayList<>();
     
    
    public void UpSalary(){
        Scanner sc = new Scanner(System.in);
        if(workerArrayList.isEmpty())
            System.out.println("No worker in the database!");
        System.out.println("------- Up/Down Salary --------");
        System.out.println("Enter code:");
        String checkCode;
        checkCode = sc.nextLine();
        int up = 0; 
        for (Worker e : workerArrayList) {
            if (e.getID().equals(checkCode)) {
                System.out.println("Enter Salary: "); 
                double addSalary = Validation.checkInputSalary();
                e.setSalary(e.getSalary() + addSalary);
                e.setStatus("UP");
                System.out.printf("Id: %s, Salary: %f, Status: %s \n", e.getID(), e.getSalary(), e.getStatus());
                Up.add(up,e);
                up++;
                break;
            }
        }
    }
    public void DownSalary(){
        Scanner sc = new Scanner(System.in);
        if(workerArrayList.isEmpty())
            System.out.println("No worker in the database!");
        System.out.println("------- Up/Down Salary --------");
        System.out.println("Enter code:");
        String checkCode;
        checkCode = sc.nextLine();
        int down = 0;
        for (Worker e : workerArrayList) {
            if (e.getID().equals(checkCode)) {
                System.out.println("Enter Salary: "); 
                double addSalary = Validation.checkInputSalary();
                if (addSalary > e.getSalary()) {
                    System.out.println("Please enter again:");
                    addSalary = Validation.checkInputSalary();
                }
                e.setSalary(e.getSalary() - addSalary);
                e.setStatus("DOWN");
                Down.add(down,e);
                down++;
                System.out.printf("Id: %s, Salary: %f, Status: %s \n", e.getID(), e.getSalary(), e.getStatus());
                break;
            }
        }
    }
    public void OutputHistorySalary(){
        System.out.println("--------------------Display Information Salary-----------------------");
        System.out.printf("%-10s%-20s%-10s%-20s%-10s%-15s\n", "Code", "Name", "Age", "Salary", "Status", "Date");
            for (Worker u : Up) {
                System.out.printf("%-10s%-20s%-10s%-20s%-10s%-15s\n", u.getID(),u.getName(), u.getAge() , u.getSalary(), u.getStatus(), u.getCurrentDate());
            }
            for (Worker d : Down) {
                System.out.printf("%-10s%-20s%-10s%-20s%-10s%-15s\n", d.getID(), d.getName(), d.getAge() , d.getSalary(), d.getStatus(), d.getCurrentDate());    
            }
    }
}

