/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_java_console_program_to_manage_a_fruit_shop;

import java.util.ArrayList;

/**
 *
 * @author MSI GL63
 */
public class Order {
    
    private String customer;
    private double total;
    ArrayList<Fruit> order = new ArrayList<>();

    public Order() {}

    public Order(String customer, double total, ArrayList<Fruit> order) {
        this.customer = customer;
        this.total = total;
        this.order = order;
    }

    public String getCustomer() {
        return customer;
    }

    public double getTotal() {
        return total;
    }

    public ArrayList<Fruit> getOrder() {
        return order;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public void setOrder(ArrayList<Fruit> order) {
        this.order = order;
    }
    
}
