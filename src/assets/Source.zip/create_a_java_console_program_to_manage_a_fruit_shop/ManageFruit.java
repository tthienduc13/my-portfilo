/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_java_console_program_to_manage_a_fruit_shop;

import java.util.ArrayList;
import java.util.Hashtable;

/**
 *
 * @author MSI GL63
 */
public class ManageFruit {
    
    private ArrayList<Fruit> fruits = new ArrayList<>();
    private ArrayList<Order> ordersList = new ArrayList<>();

    public ManageFruit() {}
    
    public ManageFruit(ArrayList<Fruit> fruits, ArrayList<Order> ordersList){
        this.fruits = fruits;
        this.ordersList = ordersList;
    }
    
    public ArrayList<Fruit> getFruit() {
        return fruits;
    }

    public ArrayList<Order> getOrdersList() {
        return ordersList;
    }
    
    public void setFruit(ArrayList<Fruit> fruits) {
        this.fruits = fruits;
    }

    public void setOrdersList(ArrayList<Order> ordersList) {
        this.ordersList = ordersList;
    }
    
    
    public void addFruit(Fruit fruit){
        fruits.add(fruit);
    }
    
    public void printFruitList(){
        System.out.println("List of Fruit:");
        System.out.printf("|%s%-5s%-20s%s\n"," ++ Item ++ |", "++ Fruit Name ++ |", "++ Origin ++ |", "++ Price ++ |");
        for (Fruit f : fruits) {
            System.out.printf("%-20s%-20s%-20s%-20s\n", f.getFruitId(), f.getFruitName(), f.getOrigin(), f.getPrice()+"$");
        }
    }
    
    public void viewOrders(){
        for (Order o : ordersList ) {
            System.out.println("Customer:" + o.getCustomer());
            System.out.printf("%-5s | %-5s | %-5s | %-5s\n","Product", "Quantity", "Price", "Amount");
            for (Fruit f : o.getOrder()) {
                double amount = f.getPrice()*f.getQuantity();
                System.out.printf("%-15s%-7s%-10s%-5s\n",f.getFruitName(), f.getQuantity(), f.getPrice(), amount+"$");
            }
            System.out.println("Total:" + o.getTotal()+"$");
        }
    }
}
