/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_java_console_program_to_manage_a_fruit_shop;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    ManageFruit manageFruit = new ManageFruit(); 
    
    private List<String> choices = Arrays.asList("FRUIT SHOP SYSTEM",
                                                "1. Create Fruit",
                                                "2. View orders",
                                                "3. Shopping (for buyer)",
                                                "4. Exit",
                                                "=======================",
                                                "Enter your choice: ");
    
    public int getChoice() {
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 4);
    }
    
    public void createFruit(){
        while (true) {            
            Fruit fruit = new Fruit();
            System.out.println("------- Create Fruit -------");
            System.out.println("Enter ID:");
            fruit.setFruitId(Validation.checkIdExist(manageFruit.getFruit()));
            System.out.println("Enter Fruit Name:");
            fruit.setFruitName(Validation.checkInputString());
            System.out.println("Enter Price:");
            fruit.setPrice(Validation.checkInputPrice());
            System.out.println("Enter Quantity:");
            fruit.setQuantity(Validation.checkInputInteger());
            System.out.println("Enter Origin:");
            fruit.setOrigin(Validation.checkInputString());
            manageFruit.addFruit(fruit);
            System.err.println("Successful!");
            if(Validation.checkInputYN() == false)
                break;
        }    
    }
    
    public void viewOrder(){
        manageFruit.viewOrders();
    }
    
    public void shopping(){
        Order order = new Order();
        ArrayList<Fruit> temp = new ArrayList<>();
        while(true){
            manageFruit.printFruitList();
            System.out.println("Please select one item:");
            int item = Validation.checkInputIntLimit(1, manageFruit.getFruit().size());
            for (Fruit f : manageFruit.getFruit()) {
                if (item == f.getFruitId()) {
                    System.out.printf("You selected: %s\n", f.getFruitName());
                    System.out.println("Please input quantity:");
                    f.setQuantity(Validation.checkInputInteger());
                    temp.add(f);
                }
            }
            System.out.println("Do you want to order now (Y/N)");
            if (Validation.checkInputYN()) {
                System.out.printf("%-5s | %-5s | %-5s | %-5s\n","Product", "Quantity", "Price", "Amount");
                double total = 0;
                for (Fruit f : temp) {
                    double amount = f.getPrice()*f.getQuantity();
                    System.out.printf("%-15s%-7s%-10s%-5s\n",f.getFruitName(), f.getQuantity(), f.getPrice(),amount +"$");
                    total = total + amount;
                }
                System.out.println("Total: "+ total+"$");
                System.out.println("Input your name:");
                order.setCustomer(Validation.checkInputString());
                order.setTotal(total);
                order.setOrder(temp);
                manageFruit.getOrdersList().add(order);
                break;
            }
        }
    }
    
    public void execute() {
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    createFruit();
                    break;
                case 2:
                    viewOrder();
                    break;
                case 3:
                    shopping();
                    break;
                case 4: 
                    System.exit(0); 
            }
        }
    }
}
