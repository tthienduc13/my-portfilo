/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package input_and_display_person_info;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author MSI GL63
 */

public class ManageInfo {
     private ArrayList<Person> persons = new ArrayList<>();
    
    public ManageInfo(){}
    
    public ManageInfo(ArrayList<Person> persons){
        this.persons = persons;
    }
    
    public ArrayList<Person> getPersons(){
        return persons;
    }

    public void setPersons(ArrayList<Person> persons) {
        this.persons = persons;
    }

    public void addPersonInfo(Person person){
        persons.add(person);
    }
    
    public ArrayList <Person> sortBySalary(){
        ArrayList <Person> result = persons;
        if(result.isEmpty())
            System.out.println("No data to sort!");
        for (int i = 0; i < result.size() - 1; i++) {
            boolean swap = false;
            for(int j = 0; j < result.size() - i - 1; j++){
                if(result.get(j).getSalary() > result.get(j + 1).getSalary()){
                    Person temp = result.get(j);
                    result.set(j, result.get(j + 1));
                    result.set(1 + j,temp);
                    swap = true;
                    if(swap == false)
                    break;
                }
            }
            
        }
         return result;
    }
    
}
