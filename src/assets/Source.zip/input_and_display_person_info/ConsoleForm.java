/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package input_and_display_person_info;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    ManageInfo manageInfo = new ManageInfo();
    
    private List<String> choices = Arrays.asList("===== Management Person Programer =====",
                                                "1. Input person information",
                                                "2. Show 3 persons information by ascending of salary",
                                                "3. Exit",
                                                "========================================",
                                                "Enter your choice: ");
    
    public int getChoice() {
        Scanner sc = new Scanner(System.in);
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1,3);
    }
    
    public void inputPersonInfo(){
        while (true) {            
            Person person = new Person();
            System.out.println("Input Information of Person");
            System.out.println("Please input name: ");
            person.setName(Validation.checkInputName());
            System.out.println("Please input address: ");
            person.setAddress(Validation.checkInputString());
            System.out.println("Please input salary: ");
            person.setSalary(Validation.checkInputSalary());
            manageInfo.addPersonInfo(person);
            System.err.println("Successful!");
            if(Validation.inputYN() == false)
                break;
            
        }
    }

    public void sortPersonBySalary(){
        ArrayList<Person> result =  new ArrayList<>();
        result = manageInfo.sortBySalary();
            for(int i = result.size()- 1; i >= result.size() - 3 ; i--){
                System.out.println("Information of Person you have entered: ");
                System.out.println("Name: " + result.get(i).getName());
                System.out.println("Address: " + result.get(i).getAddress());
                System.out.println("Salary: " + result.get(i).getSalary());
                System.out.println(""); 
            }
    }
    
    public void execute(){
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    inputPersonInfo();
                    break;
                case 2:
                    sortPersonBySalary();
                    break;
                case 3: 
                    System.exit(0); 
            }
        }    
    }
}
