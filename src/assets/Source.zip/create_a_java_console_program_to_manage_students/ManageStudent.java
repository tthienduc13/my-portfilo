/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_java_console_program_to_manage_students;

/**
 *
 * @author MSI GL63
 */

import java.util.ArrayList;
import java.util.Collections;

public class ManageStudent {
    
    private ArrayList<Student> ArrayListStudent = new ArrayList<>();
    private ArrayList<Report> Report = new ArrayList<>();
    
    public ManageStudent() {}
    
    public ManageStudent(ArrayList<Student> ArrayListStudent, ArrayList<Report> Report){
        this.ArrayListStudent = ArrayListStudent;
        this.Report = Report;
    }

    public void setArrayListStudent(ArrayList<Student> ArrayListStudent) {
        this.ArrayListStudent = ArrayListStudent;
    }

    public ArrayList<Student> getArrayListStudent() {
        return ArrayListStudent;
    }

    public void setReport(ArrayList<Report> Report) {
        this.Report = Report;
    }

    public ArrayList<Report> getReport() {
        return Report;
    }
    
    public void addInforStudent(Student student){
        ArrayListStudent.add(student);
    }
    
    public ArrayList<Student> searchInformationByName(String name) {
        ArrayList<Student> result = new ArrayList<>();
        if (ArrayListStudent.isEmpty()) {
            System.err.println("No data to find! ");
        }
        else{
            name = name.toLowerCase();
            for (Student s : ArrayListStudent) {
                if (s.getNameStudent().toLowerCase().contains(name)) {
                    result.add(s);
                }
            }   
        }
        return result;
    }

    public ArrayList<Student> sortInformationByAscendingOrder(ArrayList<Student> result ) {
        Collections.sort(result, (c1, c2) -> {
            return c1.getNameStudent().compareTo(c2.getNameStudent());
        });
        return result;
    }
    
    public ArrayList<Student> searchId(String id){
        ArrayList<Student> result = new ArrayList<>();
        for (Student s : ArrayListStudent) {
            if (s.getId().equals(id)) {
                result.add(s);
            }
        }   
        return result;
    }
    
    public void update(String id){
        if (ArrayListStudent.isEmpty()) {
            System.err.println("No data to update! ");
        }
        else{
            System.out.printf("%-5s%-5s%-20s%-15s%-10s\n","STT", "ID", "Student Name", "Semester", "Course Name");
            for (Student s : searchId(id)) {
                System.out.printf("%-5s%-5s%-20s%-15s%-10s\n", s.getStt(), s.getId(), s.getNameStudent(), s.getSemester(), s.getCourseName());
            }
            System.out.println("Which numerical order of student do you want to update: ");
            int stt = Validation.checkStt(searchId(id));
            for (Student s : ArrayListStudent) {
                if (stt == s.getStt()) {
                    System.out.println("Update Name:");
                    s.setNameStudent(Validation.checkInputString());
                    for (Student e : ArrayListStudent) {
                        if (id.equalsIgnoreCase(e.getId())) {
                            e.setNameStudent(s.getNameStudent());
                        }
                    }
                    System.out.println("Update Semester:");
                    s.setSemester(Validation.checkInputString());
                    System.out.println("Update Course Name:");
                    s.setCourseName(Validation.checkInputCourse());
                }
            }
        }   
    }
    
    public void delete(String id){
        if (ArrayListStudent.isEmpty()) {
            System.err.println("No data to delete! ");
        }
        else{
            System.out.printf("%-5s%-5s%-20s%-15s%-10s\n","STT", "ID", "Student Name", "Semester", "Course Name");
            for (Student s : searchId(id)) {
                System.out.printf("%-5s%-5s%-20s%-15s%-10s\n", s.getStt(), s.getId(), s.getNameStudent(), s.getSemester(), s.getCourseName());
            }
            System.out.println("Which numerical order of student do you want to delete: ");
            int stt = Validation.checkStt(searchId(id));
            for (int i = 0; i < ArrayListStudent.size(); i++) {
                if (stt == ArrayListStudent.get(i).getStt()) {
                    ArrayListStudent.remove(i);
                }
            }
        }
    }
    
    public void report(){
        if(ArrayListStudent.isEmpty())
            System.err.println("No data to report! ");
        else{
            for (int i = 0; i < ArrayListStudent.size(); i++) {
                int total = 0;
                for(Student sCountTotal : ArrayListStudent){
                    if(ArrayListStudent.get(i).getId().equalsIgnoreCase(sCountTotal.getId()) && ArrayListStudent.get(i).getCourseName().equalsIgnoreCase(sCountTotal.getCourseName()))
                        total++;
                }
                if(Validation.checkReportExist(Report, ArrayListStudent.get(i).getId(), ArrayListStudent.get(i).getNameStudent(), ArrayListStudent.get(i).getCourseName(), total))
                    Report.add(new Report(ArrayListStudent.get(i).getId(), ArrayListStudent.get(i).getNameStudent(), ArrayListStudent.get(i).getCourseName(), total));
            }
        }
    }
    
}

