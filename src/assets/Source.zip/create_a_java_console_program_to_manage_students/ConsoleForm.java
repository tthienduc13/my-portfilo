/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_java_console_program_to_manage_students;

/**
 *
 * @author MSI GL63
 */
import java.util.Arrays;
import java.util.List;

public class ConsoleForm {    
    
    ManageStudent manage = new ManageStudent();   
    
    int count = 0;
    
    private List<String> choices = Arrays.asList("WELCOME TO STUDENT MANAGEMENT",
                                                "===============================",
                                                "1. Create",
                                                "2. Find and Sort",
                                                "3. Update/Delete",
                                                "4. Report",
                                                "5. Exit",
                                                "===============================",
                                                "Enter your choice: ");
    
    public int getChoice() {
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 5);
    }
    
    
    public void inputInfor(){
        Student student = new Student();
        //Scanner sc = new Scanner(System.in);
        System.out.println("---------- Create information student ----------");
        System.out.println("ID:");
        student.setId(Validation.checkInputString());
        System.out.println("Name:");
        student.setNameStudent(Validation.checkIdAndName(manage.getArrayListStudent(), student.getId()));
        System.out.println("Semester:");
        student.setSemester(Validation.checkInputString());
        System.out.println("Course Name:");
        student.setCourseName(Validation.checkInputCourse());
        student.setStt(count);
        manage.addInforStudent(student);
    }
    
    public void createStudent(){
        int n = 0;
        while(n != 3){
            count++;
            inputInfor();
            n++;
            }
        while(true){
            if (Validation.checkInputYN()) {
                count++;
                inputInfor();
            }
            else
                break;
        }
    }
    
    public void displaySearchAndSort(){
        System.out.println("Enter the student name you want to search for: ");
        String name = Validation.checkInputString();
        if(!manage.sortInformationByAscendingOrder(manage.searchInformationByName(name)).isEmpty()){
            System.out.println("---------- Find And Sort ----------");
            System.out.printf("%-5s%-20s%-15s%-10s\n", "ID", "Student Name", "Semester", "Course Name");
            for(Student s : manage.sortInformationByAscendingOrder(manage.searchInformationByName(name))){
                System.out.printf("%-5s%-20s%-15s%-10s\n", s.getId(), s.getNameStudent(), s.getSemester(), s.getCourseName());
            }      
        }
        else
            System.err.println("Not found!");
    }
    
    public void displayUpdateAndDelete(){
        System.out.println("---------- Update And Delete ----------");
        System.out.println("Enter ID:");
        String id = Validation.checkIdExist(manage.getArrayListStudent());
        if (Validation.checkInputUD()) {
            manage.update(id);
            System.out.printf("%-5s%-20s%-15s%-10s\n", "ID", "Student Name", "Semester", "Course Name");
            for(Student s : manage.getArrayListStudent()){
                System.out.printf("%-5s%-20s%-15s%-10s\n", s.getId(), s.getNameStudent(), s.getSemester(), s.getCourseName());
            } 
        }
        else{
            manage.delete(id);
            System.out.printf("%-5s%-20s%-15s%-10s\n", "ID", "Student Name", "Semester", "Course Name");
            for(Student s : manage.getArrayListStudent()){
                System.out.printf("%-5s%-20s%-15s%-10s\n", s.getId(), s.getNameStudent(), s.getSemester(), s.getCourseName());
            } 
        }
        
    }
    
    public void report(){
        System.out.println("---------- Report ----------");
        manage.report();
        for(Report r : manage.getReport()){
            System.out.printf("%-5s|%-20s|%-10s|%-5s\n", r.getId(), r.getStudentName(), r.getCourseName(), r.getTotalCourse());
        }
    }
    
    public void execute() {
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    createStudent();
                    break;
                case 2:
                    displaySearchAndSort();
                    break;
                case 3:
                    displayUpdateAndDelete();
                    break;
                case 4: 
                    report();
                    break;
                case 5: 
                    System.exit(0); 
            }
        }
    }
    
}