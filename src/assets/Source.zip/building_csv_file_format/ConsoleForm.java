/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package building_csv_file_format;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    ManageCSV manageCSV = new ManageCSV();
    
    private List<String> choices = Arrays.asList("===== Format CSV Program =====",
                                                "1. Import CSV",
                                                "2. Format Address",
                                                "3. Format Name",
                                                "4. Export CSV",
                                                "5. Exit",
                                                "===============================",
                                                "Please choice one option: ");
    
    public int getChoice() {
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 5);
    }
    
    public void importCSV(){
        System.out.println("------ Import CSV ------");
        System.out.println("Enter path: ");
        manageCSV.importCSV();
    }
    
    public void formatAddress(){
        System.out.println("------ Format Address ------");
        manageCSV.formatAddress();
    }
    
    public void formatName(){
        System.out.println("------ Format Name ------");
        manageCSV.formatName();
    }
    
    public void exportCSV(){
        System.out.println("------ Export CSV ------");
        System.out.println("Enter path: ");
        manageCSV.exportFile();
    }
    
    public void execute() {
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    importCSV();
                    break;
                case 2:
                    formatAddress();
                    break;
                case 3:
                    formatName();
                    break;
                case 4: 
                    exportCSV();
                    break;
                case 5: 
                    System.exit(0); 
            }
        }
    }
    
}
