/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package write_a_calculator_program_matrix;

/**
 *
 * @author MSI GL63
 */
public class Matrix {
    private int column;
    private int row;
    private int [][] matrix;

    public Matrix() {}

    public Matrix(int column, int row, int[][] matrix) {
        this.column = column;
        this.row = row;
        this.matrix = matrix;
    }

    public int getColumn() {
        return column;
    }

    public int getRow() {
        return row;
    }

    public int[][] getMatrix() {
        return matrix;
    }

    public void setColumn(int column) {
        this.column = column;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public void setMatrix(int[][] matrix) {
        this.matrix = matrix;
    }
    
    
}
