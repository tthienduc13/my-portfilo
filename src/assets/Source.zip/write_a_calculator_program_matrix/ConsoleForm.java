/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package write_a_calculator_program_matrix;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    private List<String> choices = Arrays.asList("===== Calculator Program =====",
                                                "1. Addition Matrix",
                                                "2. Subtraction Matrix",
                                                "3. Multiplication Matrix",
                                                "4. Quit",
                                                "========================================",
                                                "Enter your choice: ");
    
    public int getChoice() {
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1,4);
    }
    
    public Matrix inputValueMatrix(int n, Matrix m){
        System.out.println("Enter Row Matrix " + n + ": ");
        m.setRow(Validation.checkInputInteger());
        System.out.println("Enter Collumn Matrix " + n + ": ");
        m.setColumn(Validation.checkInputInteger());
        int [][] matrix = new int [m.getRow()][m.getColumn()];
        for(int i = 1; i < m.getRow() + 1; i++){
            for(int j = 1; j < m.getColumn() + 1; j++){
                System.out.println("Enter Matrix" + n + "[" + i + "]" + "[" + j + "]:");
                matrix[i - 1][j - 1] = Validation.checkInputMatrixValue();
            }
        }
        m.setMatrix(matrix);
        return m;
    }
    
    public void additionMatrix(){
        System.out.println("----- Addition -----");
        CalculateMatrix calculateMatrix = new CalculateMatrix();
        calculateMatrix.setMatrix1(inputValueMatrix(1, calculateMatrix.getMatrix1()));
        calculateMatrix.setMatrix2(inputValueMatrix(2, calculateMatrix.getMatrix2()));
        System.out.println("------ Result -------");
        calculateMatrix.additionMatrix();
    }
    
    public void subtractionMatrix(){
        System.out.println("----- Subtraction -----");
        CalculateMatrix calculateMatrix = new CalculateMatrix();
        calculateMatrix.setMatrix1(inputValueMatrix(1, calculateMatrix.getMatrix1()));
        calculateMatrix.setMatrix2(inputValueMatrix(2, calculateMatrix.getMatrix2()));
        System.out.println("------ Result -------");
        calculateMatrix.subtractionMatrix();
    }
    
    public void multiplicationMatrix(){
        System.out.println("----- Multiplication -----");
        CalculateMatrix calculateMatrix = new CalculateMatrix();
        calculateMatrix.setMatrix1(inputValueMatrix(1, calculateMatrix.getMatrix1()));
        calculateMatrix.setMatrix2(inputValueMatrix(2, calculateMatrix.getMatrix2()));
        System.out.println("------ Result -------");
        calculateMatrix.multiplicationMatrix();
    }
    
    public void execute(){
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    additionMatrix();
                    break;
                case 2:
                    subtractionMatrix();
                    break;
                case 3:
                    multiplicationMatrix();
                    break;
                case 4: 
                    System.exit(0); 
            }
        }    
    }
}
