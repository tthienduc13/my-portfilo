/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package write_a_calculator_program_matrix;

/**
 *
 * @author MSI GL63
 */
public class CalculateMatrix {
    
    private Matrix matrix1 = new Matrix();
    private Matrix matrix2 = new Matrix();

    public CalculateMatrix() {
    }
    
    public CalculateMatrix(Matrix matrix1, Matrix matrix2){
        this.matrix1 = matrix1;
        this.matrix2 = matrix2;
    }
    
    public Matrix getMatrix1() {
        return matrix1;
    }

    public Matrix getMatrix2() {
        return matrix2;
    }

    public void setMatrix1(Matrix matrix1) {
        this.matrix1 = matrix1;
    }

    public void setMatrix2(Matrix matrix2) {
        this.matrix2 = matrix2;
    }
    
    public void displayMatrix(Matrix m){
        int [][] matrix = m.getMatrix();
        for (int i = 0; i < m.getRow(); i++) {
            for (int j = 0; j < m.getColumn(); j++) {
                System.out.print("[" + matrix[i][j] + "]");
            }
            System.out.println(); 
        }
    }
    
    public void additionMatrix(){          
        if (matrix1.getRow() == matrix2.getRow() && matrix1.getColumn() == matrix2.getColumn()){
            int [][] m1 = matrix1.getMatrix();
            int [][] m2 = matrix2.getMatrix();
            displayMatrix(matrix1);
            System.out.println("+");
            displayMatrix(matrix2);
            System.out.println("=");
            for (int i = 0; i < matrix1.getRow(); i++) {
                for (int j = 0; j < matrix1.getColumn(); j++) {
                    System.out.print("[" + (m1[i][j] + m2[i][j]) + "]");
                }
                System.out.println("");
            }
        }
        else
            System.err.println("Can't addition two matrices!");
    }
    
    public void subtractionMatrix(){        
        if (matrix1.getRow() == matrix2.getRow() && matrix1.getColumn() == matrix2.getColumn()){
            int [][] m1 = matrix1.getMatrix();
            int [][] m2 = matrix2.getMatrix();
            displayMatrix(matrix1);
            System.out.println("-");
            displayMatrix(matrix2);
            System.out.println("=");
            for (int i = 0; i < matrix1.getRow(); i++) {
                for (int j = 0; j < matrix1.getColumn(); j++) {
                    System.out.print("[" + (m1[i][j] - m2[i][j]) + "]");
                }
                System.out.println("");
            }            
        }
        else
            System.err.println("Can't subtraction two matrices!");
    }
    
    public void multiplicationMatrix(){         
        if (matrix1.getColumn() == matrix2.getRow()){
            int [][] m1 = matrix1.getMatrix();
            int [][] m2 = matrix2.getMatrix();
            displayMatrix(matrix1);
            System.out.println("*");
            displayMatrix(matrix2);
            System.out.println("=");
            Matrix result = new Matrix();
            result.setRow(matrix1.getRow());
            result.setColumn(matrix2.getColumn());
            int [][] resultMatrix = new int [result.getRow()][result.getColumn()];
            for (int i = 0; i < matrix1.getRow(); i++) {
                for (int j = 0; j < matrix2.getColumn(); j++) {
                    resultMatrix[i][j] = 0;
                    for (int k = 0; k < matrix1.getColumn(); k++) {
                        resultMatrix[i][j] += m1[i][k] * m2[k][j];
                    }
                }
            }
            result.setMatrix(resultMatrix);
            displayMatrix(result);
        }
        else
            System.err.println("Can't multiplication two matrices!");
    }
    
}
