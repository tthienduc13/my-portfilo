/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_program_to_analyze_file_path;

import java.util.Scanner;

/**
 *
 * @author MSI GL63
 */
public class Validation {
    
    public static String checkInputString(){
        Scanner sc = new Scanner(System.in);
        while(true){
            String input = sc.nextLine();
            if(input.isEmpty()){
                System.err.println("Please input a string! It empty!");
                System.out.println("Please enter again: ");
            }
            else
                return input;
        }
    }
}

