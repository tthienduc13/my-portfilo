/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_program_to_analyze_file_path;

import java.io.File;


/**
 *
 * @author MSI GL63
 */
public class AnalysisPath {
    
    public static String getPath(String path) {
        int fromDisk = path.indexOf("\\");
        int toNameFile = path.lastIndexOf("\\");
        return path.substring(fromDisk + 1, toNameFile);
    }
    
    public static String getFileName(String path) {
        int positionFrom = path.lastIndexOf("\\");
        int positionTo = path.lastIndexOf(".");
        return path.substring(positionFrom + 1, positionTo);
    }

    public static String getExtension(String path) {
        int positionDot = path.lastIndexOf(".");
        return path.substring(positionDot, path.length());
    }

    public static String getDisk(String path) {
        int positionColon = path.indexOf("\\");
        return path.substring(0, positionColon + 1);
    }
    
    public static String getForder(String path) {
        int positionColon = path.indexOf("\\");
        int positionDot = path.lastIndexOf("\\");
        path = path.substring(positionColon, positionDot);
        String[] splitToFile = path.split("\\\\");
        return splitToFile[splitToFile.length - 1];
    }
    
        
    public static String inputPath() {
        System.out.println("===== Analysis Path Program =====");
        System.out.println("Please input Path: ");
        String path = Validation.checkInputString();
        return path;
    }
    public static void resultAnalysisPath(String path){
        System.out.println("----- Result Analysis -----");
        File file = new File(path);
        if (file.exists() && file.isFile()) {
            System.out.println("Disk: " + getDisk(path));
            System.out.println("Extension: " + getExtension(path));
            System.out.println("File name: " + getFileName(path));
            System.out.println("Path: " + getPath(path));
        } 
        else 
            System.err.println("Path isn't file.");
    }   
}
