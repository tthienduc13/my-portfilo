/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_java_console_program_to_manage_candidates_of_company;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author MSI GL63
 */
public class ConsoleForm {
    
    ManageCandidate manageCandidate = new ManageCandidate();
    
    private List<String> choices = Arrays.asList("CANDIDATE MANAGEMENT SYSTEM",
                                                 "1. Experience",
                                                 "2. Fresher",
                                                 "3. Internship",
                                                 "4. Searching",
                                                 "5. Exit",
                                                 "============================",
                                                 "Enter your choice: ");
    
    public int getChoice() {
        choices.forEach(c -> System.out.println(c));
        return Validation.checkInputIntLimit(1, 5);
    }
    
    public void createExperience(){
        while (true) {           
            System.out.println("========== EXPERIENCE CANDIDATE ===========");
            Experience candidate = new Experience();
            System.out.println("Enter candidate id: ");
            candidate.setCandidateId(Validation.checkInputString());
            System.out.println("Enter first name: ");
            candidate.setFirstName(Validation.checkInputString());
            System.out.println("Enter last name: ");
            candidate.setLastName(Validation.checkInputString());
            System.out.println("Enter birth date: ");
            candidate.setBirthDate(Validation.checkInputBirthDate());
            System.out.println("Enter address: ");
            candidate.setAddress(Validation.checkInputString());
            System.out.println("Enter phone: ");
            candidate.setPhone(Validation.checkInputPhone());
            System.out.println("Enter email: ");
            candidate.setEmail(Validation.checkInputEmail());
            candidate.setCandidateType(0);
            System.out.println("Enter year of experience: ");
            candidate.setExpInYear(Validation.checkInputYearExperience());
            System.out.println("Enter professional skill: ");
            candidate.setProSkill(Validation.checkInputString());
            manageCandidate.addInforCandidate(candidate);
            System.err.println("Successful!");
            if(Validation.checkInputYN() == false)
                break;
       }
    }
   
    public void createFresher(){
        while (true) {        
            System.out.println("========== FRESHER CANDIDATE ==============");
            Fresher candidate = new Fresher();
            System.out.println("Enter candidate id: ");
            candidate.setCandidateId(Validation.checkInputString());
            System.out.println("Enter first name: ");
            candidate.setFirstName(Validation.checkInputString());
            System.out.println("Enter last name: ");
            candidate.setLastName(Validation.checkInputString());
            System.out.println("Enter birth date: ");
            candidate.setBirthDate(Validation.checkInputBirthDate());
            System.out.println("Enter address: ");
            candidate.setAddress(Validation.checkInputString());
            System.out.println("Enter phone: ");
            candidate.setPhone(Validation.checkInputPhone());
            System.out.println("Enter email: ");
            candidate.setEmail(Validation.checkInputEmail());
            candidate.setCandidateType(1);
            System.out.println("Enter graduated time: ");
            candidate.setGraduationDate(Validation.checkInputString());
            System.out.println("Enter rank of graduation: ");
            candidate.setGraduationRank(Validation.checkInputGraduationRank());
            System.out.println("Enter university where student graduated: ");
            candidate.setEducation(Validation.checkInputString());
            manageCandidate.addInforCandidate(candidate);
            System.err.println("Successful!");
            if(Validation.checkInputYN() == false)
                break;
       }
    }

    public void createInternship(){
        while (true) {     
            System.out.println("=========== INTERN CANDIDATE ==============");
            Internship candidate = new Internship();
            System.out.println("Enter candidate id: ");
            candidate.setCandidateId(Validation.checkInputString());
            System.out.println("Enter first name: ");
            candidate.setFirstName(Validation.checkInputString());
            System.out.println("Enter last name: ");
            candidate.setLastName(Validation.checkInputString());
            System.out.println("Enter birth date: ");
            candidate.setBirthDate(Validation.checkInputBirthDate());
            System.out.println("Enter address: ");
            candidate.setAddress(Validation.checkInputString());
            System.out.println("Enter phone: ");
            candidate.setPhone(Validation.checkInputPhone());
            System.out.println("Enter email: ");
            candidate.setEmail(Validation.checkInputEmail());
            candidate.setCandidateType(2);
            System.out.println("Enter major: ");
            candidate.setMajors(Validation.checkInputString());
            System.out.println("Enter semester: ");
            candidate.setSemester(Validation.checkInputString());
            System.out.println("Enter university name: ");
            candidate.setUniversityName(Validation.checkInputString());
            manageCandidate.addInforCandidate(candidate);
            System.err.println("Successful!");
            if(Validation.checkInputYN() == false)
                break;
        }
    }
        
    public void printListCandidates(){
        System.out.println("========== EXPERIENCE CANDIDATE ===========");
        for (Candidate c : manageCandidate.getCandidates()) {
            if(c instanceof Experience)
                System.out.println(c.getFirstName() + " " + c.getLastName());
        }
        System.out.println("========== FRESHER CANDIDATE ==============");
        for (Candidate c : manageCandidate.getCandidates()) {
            if(c instanceof Fresher)
                System.out.println(c.getFirstName() + " " + c.getLastName());
        }
        System.out.println("=========== INTERN CANDIDATE ==============");
        for (Candidate c : manageCandidate.getCandidates()) {
            if(c instanceof Internship)
                System.out.println(c.getFirstName() + " " + c.getLastName());
        }
    }
    
    public void searchCandidates(){
        if(manageCandidate.getCandidates().isEmpty())
            System.out.println("No data to search!");
        else{
            printListCandidates();
            System.out.println("=========== SEARCHING ==============");
            System.out.println("Input Candidate name (First name or Last name): ");
            String name = Validation.checkInputString();
            System.out.println("Input type of candidate: ");
            int type = Validation.checkInputIntLimit(0, 2);
            manageCandidate.searchCandidate(name, type);
        }
    }

    public void execute(){
        while(true) {
            int choice = getChoice();
            switch (choice) {
                case 1: 
                    createExperience();
                    break;
                case 2:
                    createFresher();
                    break;
                case 3:
                    createInternship();
                    break; 
                case 4:
                    searchCandidates();
                    break;
                case 5: 
                    System.exit(0); 
            }
        }    
    }
}
