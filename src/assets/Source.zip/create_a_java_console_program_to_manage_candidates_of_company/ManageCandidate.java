/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create_a_java_console_program_to_manage_candidates_of_company;

import java.util.ArrayList;

/**
 *
 * @author MSI GL63
 */
public class ManageCandidate {
    
    private  ArrayList<Candidate> candidates = new ArrayList<>();

    public ManageCandidate() {}
    
    public ManageCandidate(ArrayList<Candidate> candidates){
        this.candidates = candidates;
    }

    public ArrayList<Candidate> getCandidates() {
        return candidates;
    }

    public void setCandidates(ArrayList<Candidate> candidates) {
        this.candidates = candidates;
    }
    
    public void addInforCandidate(Candidate candidate){
        candidates.add(candidate);
    }
    
    public  void searchCandidate(String nameSearch, int typeCandidate){
        for (Candidate c : candidates) {
            if(c.getCandidateType() == typeCandidate && c.getFirstName().contains(nameSearch) || c.getLastName().contains(nameSearch))
                System.out.println(c.toString());
        }
    }
}
